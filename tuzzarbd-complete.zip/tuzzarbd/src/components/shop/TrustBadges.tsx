// src/components/shop/TrustBadges.tsx
import { Truck, Shield, RotateCcw, Phone } from "lucide-react";
export default function TrustBadges() {
  const badges = [
    { icon: Truck, title: "দ্রুত ডেলিভারি", desc: "ঢাকায় ৳৮০ | সারা বাংলাদেশ ৳১৫০", color: "text-blue-600 bg-blue-50" },
    { icon: Shield, title: "১০০% অরিজিনাল", desc: "সকল পণ্য গ্যারান্টিযুক্ত", color: "text-green-600 bg-green-50" },
    { icon: RotateCcw, title: "সহজ রিটার্ন", desc: "৭ দিনের মধ্যে রিটার্ন করুন", color: "text-purple-600 bg-purple-50" },
    { icon: Phone, title: "২৪/৭ সাপোর্ট", desc: "WhatsApp-এ সবসময় পাশে আছি", color: "text-brand-600 bg-brand-50" },
  ];
  return (
    <section className="border-y border-gray-100 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-gray-100">
          {badges.map((b) => (
            <div key={b.title} className="flex items-center gap-3 py-5 px-4 md:px-6">
              <span className={`p-2.5 rounded-xl flex-shrink-0 ${b.color}`}>
                <b.icon className="w-5 h-5" />
              </span>
              <div className="min-w-0">
                <p className="font-semibold text-accent text-sm font-bangla">{b.title}</p>
                <p className="text-xs text-gray-400 font-bangla truncate">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
