// src/components/shop/FeaturedProducts.tsx
"use client";
import Link from "next/link";
import { ShoppingCart, Heart, Star, ArrowRight, Zap } from "lucide-react";
import { useState } from "react";
import toast from "react-hot-toast";
import { MetaPixel } from "@/lib/tracking";

interface Product {
  id: string; name: string; slug: string; price: number;
  comparePrice?: number; image: string; rating: number;
  reviews: number; badge?: string; category: string; isNew?: boolean;
}

const SAMPLE_PRODUCTS: Product[] = [
  { id: "1", name: "প্রিমিয়াম কটন শার্ট", slug: "premium-cotton-shirt", price: 850, comparePrice: 1200, image: "👕", rating: 4.5, reviews: 128, badge: "৩০% ছাড়", category: "Fashion" },
  { id: "2", name: "Samsung Galaxy Buds 2 Pro", slug: "samsung-buds-2-pro", price: 12500, comparePrice: 15000, image: "🎧", rating: 4.8, reviews: 52, badge: "বেস্টসেলার", category: "Gadgets" },
  { id: "3", name: "ভিটামিন C ফেসওয়াশ (100ml)", slug: "vitamin-c-facewash", price: 350, image: "🧴", rating: 4.3, reviews: 234, badge: "নতুন", category: "Beauty", isNew: true },
  { id: "4", name: "ফ্লোরাল প্রিন্ট শাড়ি", slug: "floral-print-saree", price: 2200, comparePrice: 2800, image: "👘", rating: 4.7, reviews: 89, badge: "হট", category: "Fashion" },
  { id: "5", name: "Xiaomi Redmi Note 13 Pro", slug: "redmi-note-13-pro", price: 32000, comparePrice: 35000, image: "📱", rating: 4.6, reviews: 67, badge: "অফার", category: "Gadgets" },
  { id: "6", name: "আর্গান হেয়ার অয়েল (50ml)", slug: "argan-hair-oil", price: 480, image: "🌿", rating: 4.4, reviews: 156, category: "Beauty", isNew: true },
  { id: "7", name: "পাঞ্জাবি - সাদা (XL)", slug: "panjabi-white-xl", price: 1200, comparePrice: 1500, image: "🥼", rating: 4.5, reviews: 43, category: "Fashion" },
  { id: "8", name: "Smart Watch Series 9", slug: "smart-watch-series-9", price: 8500, comparePrice: 11000, image: "⌚", rating: 4.7, reviews: 31, badge: "লিমিটেড", category: "Gadgets" },
];

function ProductCard({ product }: { product: Product }) {
  const [wishlisted, setWishlisted] = useState(false);
  const discount = product.comparePrice ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100) : 0;

  const handleAddToCart = () => {
    MetaPixel.addToCart({ content_ids: [product.id], content_name: product.name, value: product.price, currency: "BDT", quantity: 1 });
    toast.success(`${product.name} কার্টে যোগ করা হয়েছে!`);
  };

  return (
    <div className="product-card group">
      <div className="relative overflow-hidden bg-gray-50">
        {product.badge && (
          <span className="absolute top-3 left-3 z-10 bg-brand-500 text-white text-xs font-bold px-2.5 py-1 rounded-lg">
            {product.badge}
          </span>
        )}
        {discount > 0 && (
          <span className="absolute top-3 right-3 z-10 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-lg">
            -{discount}%
          </span>
        )}
        <button
          onClick={() => setWishlisted(!wishlisted)}
          className="absolute bottom-3 right-3 z-10 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <Heart className={`w-4 h-4 ${wishlisted ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
        </button>

        <Link href={`/product/${product.slug}`}>
          <div className="aspect-square flex items-center justify-center text-7xl bg-gradient-to-br from-gray-50 to-gray-100 group-hover:from-brand-50 group-hover:to-orange-50 transition-colors duration-300 py-6">
            {product.image}
          </div>
        </Link>
      </div>

      <div className="p-4">
        <p className="text-xs text-gray-400 font-bangla mb-1">{product.category}</p>
        <Link href={`/product/${product.slug}`}>
          <h3 className="font-semibold text-accent text-sm font-bangla leading-snug hover:text-brand-600 transition-colors line-clamp-2 mb-2">
            {product.name}
          </h3>
        </Link>

        <div className="flex items-center gap-1.5 mb-3">
          <div className="flex">
            {[1,2,3,4,5].map((s) => (
              <Star key={s} className={`w-3 h-3 ${s <= Math.round(product.rating) ? "fill-amber-400 text-amber-400" : "text-gray-200"}`} />
            ))}
          </div>
          <span className="text-xs text-gray-400">({product.reviews})</span>
        </div>

        <div className="flex items-end justify-between gap-2">
          <div>
            <p className="text-lg font-bold text-accent">৳{product.price.toLocaleString()}</p>
            {product.comparePrice && (
              <p className="text-xs text-gray-400 line-through">৳{product.comparePrice.toLocaleString()}</p>
            )}
          </div>
          <button
            onClick={handleAddToCart}
            className="flex items-center gap-1.5 bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold px-3 py-2 rounded-xl transition-all hover:-translate-y-0.5 shadow-sm"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span className="font-bangla">কার্টে যোগ</span>
          </button>
        </div>
      </div>
    </div>
  );
}

interface Props {
  title?: string;
  subtitle?: string;
  type?: "featured" | "new";
}

export default function FeaturedProducts({ title = "ফিচার্ড পণ্য", subtitle = "সেরা পণ্যসমূহ", type = "featured" }: Props) {
  const products = type === "new"
    ? SAMPLE_PRODUCTS.filter((p) => p.isNew)
    : SAMPLE_PRODUCTS.slice(0, 8);

  return (
    <section className="py-14 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4 text-brand-500" />
              <p className="text-brand-600 text-sm font-semibold font-bangla">{subtitle}</p>
            </div>
            <h2 className="section-title font-bangla">{title}</h2>
          </div>
          <Link href="/shop" className="hidden md:flex items-center gap-1.5 text-sm text-brand-600 font-semibold hover:text-brand-700 font-bangla">
            সব পণ্য দেখুন <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>

        <div className="text-center mt-8 md:hidden">
          <Link href="/shop" className="btn-secondary font-bangla text-sm">
            সব পণ্য দেখুন
          </Link>
        </div>
      </div>
    </section>
  );
}
