// src/components/shop/HeroSection.tsx
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowRight, ChevronLeft, ChevronRight, Zap, Truck, Shield } from "lucide-react";

const SLIDES = [
  {
    id: 1,
    badge: "🔥 গরম অফার",
    title: "স্মার্ট গ্যাজেট",
    subtitle: "সেরা দামে",
    desc: "Samsung, Xiaomi, Realme — সব ব্র্যান্ডের অফিশিয়াল পণ্য",
    cta: "এখনই দেখুন",
    href: "/shop/gadgets",
    bg: "from-blue-900 via-indigo-900 to-slate-900",
    accent: "#3b82f6",
    image: "📱",
    stats: [{ label: "পণ্য", value: "৫০০+" }, { label: "ব্র্যান্ড", value: "৩০+" }, { label: "রিভিউ", value: "৪.৮★" }],
  },
  {
    id: 2,
    badge: "✨ নতুন কালেকশন",
    title: "ফ্যাশন",
    subtitle: "ট্রেন্ডি স্টাইলে",
    desc: "পুরুষ, মহিলা ও শিশুদের জন্য সেরা পোশাক সংগ্রহ",
    cta: "কালেকশন দেখুন",
    href: "/shop/fashion",
    bg: "from-rose-900 via-pink-900 to-purple-900",
    accent: "#ec4899",
    image: "👗",
    stats: [{ label: "ডিজাইন", value: "২০০+" }, { label: "সাইজ", value: "XS-XXL" }, { label: "ফেব্রিক", value: "প্রিমিয়াম" }],
  },
  {
    id: 3,
    badge: "🌿 অর্গানিক",
    title: "বিউটি কেয়ার",
    subtitle: "প্রাকৃতিক উপাদানে",
    desc: "হালাল সার্টিফাইড, ত্বক ও চুলের যত্নে বিশ্বমানের পণ্য",
    cta: "পণ্য দেখুন",
    href: "/shop/beauty",
    bg: "from-purple-900 via-violet-900 to-fuchsia-900",
    accent: "#a855f7",
    image: "✨",
    stats: [{ label: "হালাল", value: "১০০%" }, { label: "অর্গানিক", value: "নিশ্চিত" }, { label: "পার্শ্বক্রিয়া", value: "শূন্য" }],
  },
];

export default function HeroSection() {
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      goTo((current + 1) % SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [current]);

  const goTo = (idx: number) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrent(idx);
    setTimeout(() => setIsAnimating(false), 400);
  };

  const slide = SLIDES[current];

  return (
    <section className={`relative bg-gradient-to-br ${slide.bg} overflow-hidden transition-all duration-700`}>
      {/* Background Decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div
          className="absolute -top-40 -right-40 w-96 h-96 rounded-full opacity-20 blur-3xl"
          style={{ background: slide.accent }}
        />
        <div
          className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full opacity-10 blur-3xl"
          style={{ background: slide.accent }}
        />
        {/* Grid pattern */}
        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }}
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div
            key={current}
            className="text-white space-y-6"
            style={{ animation: "fadeIn 0.5s ease-out" }}
          >
            {/* Badge */}
            <span className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-semibold border border-white/20">
              {slide.badge}
            </span>

            {/* Title */}
            <div>
              <h1 className="text-5xl md:text-6xl font-bold font-display leading-tight">
                <span className="text-white">{slide.title}</span>
                <br />
                <span style={{ color: slide.accent }} className="opacity-90">
                  {slide.subtitle}
                </span>
              </h1>
            </div>

            <p className="text-white/70 text-lg font-bangla leading-relaxed max-w-md">
              {slide.desc}
            </p>

            {/* Stats */}
            <div className="flex gap-6">
              {slide.stats.map((stat) => (
                <div key={stat.label}>
                  <p className="text-xl font-bold text-white">{stat.value}</p>
                  <p className="text-xs text-white/60 font-bangla">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap gap-3 pt-2">
              <Link
                href={slide.href}
                className="inline-flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white font-semibold px-6 py-3 rounded-xl transition-all hover:-translate-y-0.5 shadow-brand font-bangla"
              >
                {slide.cta}
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/shop"
                className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-6 py-3 rounded-xl transition-all border border-white/20 font-bangla backdrop-blur-sm"
              >
                সব পণ্য
              </Link>
            </div>
          </div>

          {/* Visual */}
          <div className="hidden lg:flex items-center justify-center">
            <div
              key={current}
              className="relative"
              style={{ animation: "bounceIn 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)" }}
            >
              {/* Giant emoji with glow */}
              <div
                className="text-[180px] leading-none select-none filter drop-shadow-2xl"
                style={{ textShadow: `0 0 80px ${slide.accent}80` }}
              >
                {slide.image}
              </div>

              {/* Floating Cards */}
              <div className="absolute -top-4 -left-8 bg-white/10 backdrop-blur-md rounded-2xl px-4 py-3 border border-white/20 animate-pulse-soft">
                <p className="text-white text-xs font-bangla">🚚 দ্রুত ডেলিভারি</p>
                <p className="text-white/70 text-xs font-bangla">১-৩ কার্যদিবস</p>
              </div>

              <div
                className="absolute -bottom-2 -right-4 bg-white/10 backdrop-blur-md rounded-2xl px-4 py-3 border border-white/20 animate-pulse-soft"
                style={{ animationDelay: "1s" }}
              >
                <p className="text-white text-xs font-bangla">✅ ১০০% অরিজিনাল</p>
                <p className="text-white/70 text-xs font-bangla">গ্যারান্টি সহ</p>
              </div>
            </div>
          </div>
        </div>

        {/* Slider Controls */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-3">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              className={`transition-all duration-300 rounded-full ${
                i === current
                  ? "w-8 h-2.5 bg-brand-400"
                  : "w-2.5 h-2.5 bg-white/30 hover:bg-white/50"
              }`}
            />
          ))}
        </div>

        {/* Arrow Controls */}
        <button
          onClick={() => goTo((current - 1 + SLIDES.length) % SLIDES.length)}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/10 hover:bg-white/20 rounded-xl border border-white/20 text-white backdrop-blur-sm transition-all hidden md:flex"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={() => goTo((current + 1) % SLIDES.length)}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/10 hover:bg-white/20 rounded-xl border border-white/20 text-white backdrop-blur-sm transition-all hidden md:flex"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </section>
  );
}
