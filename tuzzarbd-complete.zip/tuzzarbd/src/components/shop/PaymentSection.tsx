// src/components/shop/PaymentSection.tsx
// Drop-in payment section for checkout
"use client";
import { useState } from "react";
import { Loader2, ExternalLink, CheckCircle } from "lucide-react";
import toast from "react-hot-toast";

interface PaymentSectionProps {
  orderId: string;
  orderNumber: string;
  total: number;
  paymentMethod: string;
}

export default function PaymentSection({ orderId, orderNumber, total, paymentMethod }: PaymentSectionProps) {
  const [loading, setLoading] = useState(false);

  const handleBkashPayment = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/payments/bkash/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId, amount: total }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      // Redirect to bKash payment page
      window.location.href = data.bkashURL;
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "bKash পেমেন্ট শুরু করা যায়নি";
      toast.error(message);
      setLoading(false);
    }
  };

  const handleNagadPayment = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/payments/nagad/initialize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      window.location.href = data.callBackUrl;
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "নগদ পেমেন্ট শুরু করা যায়নি";
      toast.error(message);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="card p-5 border-2 border-brand-100 bg-brand-50">
        <div className="flex items-center gap-3 mb-4">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <div>
            <p className="font-bold text-accent font-bangla">অর্ডার #{orderNumber} তৈরি হয়েছে!</p>
            <p className="text-sm text-gray-500 font-bangla">মোট: ৳{total.toLocaleString()}</p>
          </div>
        </div>

        {paymentMethod === "COD" && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
            <p className="text-2xl mb-2">💵</p>
            <p className="font-bold text-green-800 font-bangla">ক্যাশ অন ডেলিভারি নির্বাচিত</p>
            <p className="text-sm text-green-700 font-bangla mt-1">পণ্য পাওয়ার পর পেমেন্ট করুন</p>
          </div>
        )}

        {paymentMethod === "BKASH" && (
          <button
            onClick={handleBkashPayment}
            disabled={loading}
            className="w-full py-4 rounded-xl font-bold text-white flex items-center justify-center gap-3 text-lg disabled:opacity-70 transition-all hover:-translate-y-0.5"
            style={{ background: "#E2136E" }}
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <span className="text-2xl">💳</span>
                <span className="font-bangla">bKash দিয়ে পেমেন্ট করুন</span>
                <ExternalLink className="w-4 h-4" />
              </>
            )}
          </button>
        )}

        {paymentMethod === "NAGAD" && (
          <button
            onClick={handleNagadPayment}
            disabled={loading}
            className="w-full py-4 rounded-xl font-bold text-white flex items-center justify-center gap-3 text-lg disabled:opacity-70 transition-all hover:-translate-y-0.5"
            style={{ background: "#F5821F" }}
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <span className="text-2xl">💳</span>
                <span className="font-bangla">Nagad দিয়ে পেমেন্ট করুন</span>
                <ExternalLink className="w-4 h-4" />
              </>
            )}
          </button>
        )}

        {paymentMethod === "ROCKET" && (
          <div className="text-center p-4 bg-purple-50 border border-purple-200 rounded-xl">
            <p className="font-bold text-purple-800 font-bangla">Rocket নম্বরে পেমেন্ট করুন</p>
            <p className="text-2xl font-mono font-bold text-purple-900 my-2">01XXXXXXXXX</p>
            <p className="text-sm text-purple-700 font-bangla">পেমেন্টের পর অর্ডার নম্বর WhatsApp-এ পাঠান</p>
          </div>
        )}
      </div>

      {/* Security Note */}
      <p className="text-xs text-center text-gray-400 font-bangla">
        🔒 আপনার পেমেন্ট তথ্য সম্পূর্ণ এনক্রিপ্টেড ও নিরাপদ
      </p>
    </div>
  );
}
