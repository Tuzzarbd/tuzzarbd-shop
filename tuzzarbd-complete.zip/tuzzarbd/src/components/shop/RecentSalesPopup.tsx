// src/components/shop/RecentSalesPopup.tsx
"use client";
import { useState, useEffect } from "react";
import { X, ShoppingBag } from "lucide-react";

const FAKE_SALES = [
  { name: "রহিম উ.", location: "ঢাকা", product: "কটন শার্ট - Navy Blue", time: "২ মিনিট আগে" },
  { name: "সুমাইয়া খ.", location: "চট্টগ্রাম", product: "ভিটামিন C ফেসওয়াশ", time: "৫ মিনিট আগে" },
  { name: "করিম আ.", location: "সিলেট", product: "Samsung Galaxy Buds", time: "৮ মিনিট আগে" },
  { name: "ফারিয়া ই.", location: "রাজশাহী", product: "ফ্লোরাল শাড়ি", time: "১২ মিনিট আগে" },
  { name: "তানভীর হ.", location: "খুলনা", product: "Xiaomi Redmi Note 13", time: "১৫ মিনিট আগে" },
  { name: "নাজমা বে.", location: "বরিশাল", product: "হেয়ার সিরাম", time: "২০ মিনিট আগে" },
];

export default function RecentSalesPopup() {
  const [current, setCurrent] = useState<typeof FAKE_SALES[0] | null>(null);
  const [visible, setVisible] = useState(false);
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const show = () => {
      setCurrent(FAKE_SALES[idx % FAKE_SALES.length]);
      setVisible(true);
      setIdx((i) => i + 1);
      setTimeout(() => setVisible(false), 4000);
    };
    const initial = setTimeout(show, 4000);
    const interval = setInterval(show, 10000);
    return () => { clearTimeout(initial); clearInterval(interval); };
  }, [idx]);

  if (!current || !visible) return null;

  return (
    <div className="fixed bottom-24 left-4 z-40 max-w-xs recent-sale-popup">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-4 flex items-center gap-3">
        <div className="w-10 h-10 bg-brand-100 rounded-xl flex items-center justify-center flex-shrink-0">
          <ShoppingBag className="w-5 h-5 text-brand-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-gray-500 font-bangla">
            <span className="font-semibold text-accent">{current.name}</span> ({current.location}) কিনেছেন
          </p>
          <p className="text-sm font-bold text-gray-800 font-bangla truncate">{current.product}</p>
          <p className="text-xs text-brand-500 font-bangla">{current.time}</p>
        </div>
        <button onClick={() => setVisible(false)} className="text-gray-300 hover:text-gray-500">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

// ========================
// src/components/ui/MetaPixelScript.tsx
// ========================
