// src/components/shop/CategoryGrid.tsx
import Link from "next/link";
import { ArrowRight } from "lucide-react";

const CATEGORIES = [
  {
    id: "fashion",
    title: "ফ্যাশন",
    subtitle: "পুরুষ • মহিলা • শিশু",
    href: "/shop/fashion",
    emoji: "👗",
    gradient: "from-rose-400 to-pink-600",
    stats: "২০০+ পণ্য",
    tag: "নতুন কালেকশন",
  },
  {
    id: "gadgets",
    title: "স্মার্ট গ্যাজেট",
    subtitle: "ফোন • ইয়ারফোন • স্মার্টওয়াচ",
    href: "/shop/gadgets",
    emoji: "📱",
    gradient: "from-blue-500 to-indigo-700",
    stats: "৩০০+ পণ্য",
    tag: "হট ডিল",
  },
  {
    id: "beauty",
    title: "বিউটি কেয়ার",
    subtitle: "স্কিন • মেকআপ • হেয়ার",
    href: "/shop/beauty",
    emoji: "✨",
    gradient: "from-purple-500 to-violet-700",
    stats: "১৫০+ পণ্য",
    tag: "হালাল সার্টিফাইড",
  },
];

export default function CategoryGrid() {
  return (
    <section className="py-14 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-brand-600 text-sm font-semibold font-bangla mb-1">আমাদের ক্যাটাগরি</p>
            <h2 className="section-title font-bangla">সব ধরনের পণ্য</h2>
          </div>
          <Link href="/shop" className="hidden md:flex items-center gap-1.5 text-sm text-brand-600 font-semibold hover:text-brand-700 font-bangla">
            সব দেখুন <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              href={cat.href}
              className={`group relative overflow-hidden rounded-3xl bg-gradient-to-br ${cat.gradient} p-8 text-white min-h-[220px] flex flex-col justify-between hover:shadow-2xl transition-all duration-300 hover:-translate-y-1`}
            >
              {/* Background deco */}
              <div className="absolute -right-8 -top-8 text-[120px] opacity-20 group-hover:opacity-30 transition-opacity duration-300 select-none">
                {cat.emoji}
              </div>

              <div>
                <span className="inline-flex items-center bg-white/20 text-white text-xs px-3 py-1 rounded-full font-semibold font-bangla backdrop-blur-sm mb-3">
                  {cat.tag}
                </span>
                <h3 className="text-2xl font-bold font-display">{cat.title}</h3>
                <p className="text-white/80 text-sm font-bangla mt-1">{cat.subtitle}</p>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-white/70 text-sm font-bangla">{cat.stats}</span>
                <span className="flex items-center gap-1 bg-white/20 hover:bg-white/30 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-all font-bangla backdrop-blur-sm">
                  দেখুন <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
