// src/components/layout/Footer.tsx
import Link from "next/link";
import { ShoppingBag, MapPin, Phone, Mail, Facebook, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-accent text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-xl">tuzzarbd</span>
            </Link>
            <p className="text-white/60 text-sm font-bangla leading-relaxed mb-5">
              বাংলাদেশের প্রিমিয়াম অনলাইন শপ। ফ্যাশন, গ্যাজেট ও বিউটি কেয়ারের সেরা পণ্য।
            </p>
            <div className="space-y-2 text-sm text-white/60">
              <div className="flex items-center gap-2 font-bangla">
                <MapPin className="w-4 h-4 text-brand-400 flex-shrink-0" />
                ঢাকা, বাংলাদেশ
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-brand-400 flex-shrink-0" />
                <a href="tel:01XXXXXXXXXX" className="hover:text-white">01XXXXXXXXXX</a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-brand-400 flex-shrink-0" />
                <a href="mailto:hello@tuzzarbd.com" className="hover:text-white">hello@tuzzarbd.com</a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-white mb-4 font-display">দ্রুত লিংক</h3>
            <ul className="space-y-2.5 text-sm text-white/60">
              {[
                { href: "/shop/fashion", label: "ফ্যাশন" },
                { href: "/shop/gadgets", label: "স্মার্ট গ্যাজেট" },
                { href: "/shop/beauty", label: "বিউটি কেয়ার" },
                { href: "/shop?featured=true", label: "বেস্টসেলার" },
                { href: "/shop?new=true", label: "নতুন পণ্য" },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="hover:text-white transition-colors font-bangla">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer */}
          <div>
            <h3 className="font-bold text-white mb-4 font-display">কাস্টমার সার্ভিস</h3>
            <ul className="space-y-2.5 text-sm text-white/60">
              {[
                { href: "/order-tracking", label: "অর্ডার ট্র্যাক করুন" },
                { href: "/account", label: "আমার অ্যাকাউন্ট" },
                { href: "/returns", label: "রিটার্ন পলিসি" },
                { href: "/faq", label: "সাধারণ প্রশ্ন" },
                { href: "/contact", label: "যোগাযোগ করুন" },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="hover:text-white transition-colors font-bangla">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Delivery */}
          <div>
            <h3 className="font-bold text-white mb-4 font-display">ডেলিভারি তথ্য</h3>
            <div className="space-y-3 text-sm">
              <div className="bg-white/10 rounded-xl p-3">
                <p className="text-brand-300 font-bold font-bangla mb-1">🏙️ ঢাকার ভেতরে</p>
                <p className="text-white/70 font-bangla">শিপিং চার্জ: <span className="text-white font-bold">৳৮০</span></p>
                <p className="text-white/50 text-xs font-bangla">ডেলিভারি: ১-২ কার্যদিবস</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3">
                <p className="text-brand-300 font-bold font-bangla mb-1">🗺️ সারা বাংলাদেশ</p>
                <p className="text-white/70 font-bangla">শিপিং চার্জ: <span className="text-white font-bold">৳১৫০</span></p>
                <p className="text-white/50 text-xs font-bangla">ডেলিভারি: ২-৪ কার্যদিবস</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/40 text-sm font-bangla text-center">
            © ২০২৪ tuzzarbd. সর্বস্বত্ব সংরক্ষিত।
          </p>
          <div className="flex items-center gap-4">
            <a href="https://facebook.com/tuzzarbd" target="_blank" rel="noopener noreferrer"
              className="w-9 h-9 bg-white/10 rounded-xl flex items-center justify-center hover:bg-brand-500 transition-colors">
              <Facebook className="w-4 h-4" />
            </a>
            <a href="https://instagram.com/tuzzarbd" target="_blank" rel="noopener noreferrer"
              className="w-9 h-9 bg-white/10 rounded-xl flex items-center justify-center hover:bg-brand-500 transition-colors">
              <Instagram className="w-4 h-4" />
            </a>
          </div>
          <div className="flex gap-4 text-xs text-white/40">
            <Link href="/privacy" className="hover:text-white transition-colors font-bangla">গোপনীয়তা নীতি</Link>
            <Link href="/terms" className="hover:text-white transition-colors font-bangla">শর্তাবলী</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
