// src/components/layout/Header.tsx
"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ShoppingBag, Search, Menu, X, ChevronDown, Heart,
  Shirt, Cpu, Sparkles, Phone, MapPin, Tag, TrendingUp,
  ShoppingCart, User, ArrowRight
} from "lucide-react";

const CATEGORIES = [
  {
    id: "fashion",
    label: "ফ্যাশন",
    icon: Shirt,
    color: "text-pink-600 bg-pink-50",
    href: "/shop/fashion",
    featured: "নতুন কালেকশন",
    subcategories: [
      { label: "পুরুষ পোশাক", href: "/shop/fashion/mens", items: ["শার্ট", "প্যান্ট", "পাঞ্জাবি", "টি-শার্ট"] },
      { label: "মহিলা পোশাক", href: "/shop/fashion/womens", items: ["শাড়ি", "সালোয়ার কামিজ", "কুর্তি", "থ্রি-পিস"] },
      { label: "শিশু পোশাক", href: "/shop/fashion/kids", items: ["ছেলে", "মেয়ে", "নিউবর্ন"] },
      { label: "আনুষাঙ্গিক", href: "/shop/fashion/accessories", items: ["ব্যাগ", "বেল্ট", "ঘড়ি", "জুতা"] },
    ],
    banner: { title: "সিজন সেল", subtitle: "৩০% পর্যন্ত ছাড়", color: "from-pink-500 to-rose-600" },
  },
  {
    id: "gadgets",
    label: "স্মার্ট গ্যাজেট",
    icon: Cpu,
    color: "text-blue-600 bg-blue-50",
    href: "/shop/gadgets",
    featured: "নতুন আগমন",
    subcategories: [
      { label: "স্মার্টফোন", href: "/shop/gadgets/smartphones", items: ["Samsung", "Xiaomi", "Realme", "iPhone"] },
      { label: "ইয়ারফোন", href: "/shop/gadgets/earphones", items: ["TWS", "Wired", "Headphone", "Neckband"] },
      { label: "স্মার্টওয়াচ", href: "/shop/gadgets/smartwatch", items: ["Samsung", "Xiaomi", "Amazfit"] },
      { label: "আনুষাঙ্গিক", href: "/shop/gadgets/accessories", items: ["চার্জার", "কেস", "পাওয়ার ব্যাংক"] },
    ],
    banner: { title: "টেক ডিল", subtitle: "সেরা দামে সেরা পণ্য", color: "from-blue-500 to-indigo-600" },
  },
  {
    id: "beauty",
    label: "বিউটি কেয়ার",
    icon: Sparkles,
    color: "text-purple-600 bg-purple-50",
    href: "/shop/beauty",
    featured: "বেস্টসেলার",
    subcategories: [
      { label: "স্কিনকেয়ার", href: "/shop/beauty/skincare", items: ["ফেসওয়াশ", "ময়েশ্চারাইজার", "সিরাম", "সানস্ক্রিন"] },
      { label: "মেকআপ", href: "/shop/beauty/makeup", items: ["লিপস্টিক", "ফাউন্ডেশন", "আইশ্যাডো"] },
      { label: "হেয়ার কেয়ার", href: "/shop/beauty/haircare", items: ["শ্যাম্পু", "কন্ডিশনার", "হেয়ার অয়েল"] },
      { label: "পারফিউম", href: "/shop/beauty/perfume", items: ["আতর", "বডি স্প্রে", "ডিওড্রেন্ট"] },
    ],
    banner: { title: "বিউটি এসেনশিয়ালস", subtitle: "অর্গানিক ও হালাল", color: "from-purple-500 to-pink-600" },
  },
];

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeMega, setActiveMega] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [scrolled, setScrolled] = useState(false);
  const [cartCount] = useState(2);
  const pathname = usePathname();
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setActiveMega(null);
  }, [pathname]);

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  return (
    <>
      {/* Top Bar */}
      <div className="bg-accent text-white text-xs py-2 hidden md:block">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-4 font-bangla">
            <span className="flex items-center gap-1.5">
              <Phone className="w-3 h-3" />
              ০১XXXXXXXXXX
            </span>
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3 h-3" />
              ঢাকায় ৳৮০ | সারা বাংলাদেশ ৳১৫০
            </span>
          </div>
          <div className="flex items-center gap-4 font-bangla">
            <Link href="/order-tracking" className="hover:text-brand-300 transition-colors flex items-center gap-1">
              <Tag className="w-3 h-3" />
              অর্ডার ট্র্যাক করুন
            </Link>
            <Link href="/admin/login" className="hover:text-brand-300 transition-colors">
              Admin Panel
            </Link>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header
        className={`sticky top-0 z-40 bg-white transition-shadow duration-300 ${
          scrolled ? "shadow-md" : "border-b border-gray-100"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center h-16 gap-4">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 flex-shrink-0">
              <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center shadow-brand">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-xl text-accent hidden sm:block">
                tuzzarbd
              </span>
            </Link>

            {/* Desktop Mega Menu */}
            <nav className="hidden lg:flex items-center gap-1 ml-4">
              {CATEGORIES.map((cat) => (
                <div
                  key={cat.id}
                  className="mega-menu-trigger relative"
                  onMouseEnter={() => setActiveMega(cat.id)}
                  onMouseLeave={() => setActiveMega(null)}
                >
                  <button
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all font-bangla ${
                      activeMega === cat.id
                        ? "bg-brand-50 text-brand-700"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    <cat.icon className="w-4 h-4" />
                    {cat.label}
                    <ChevronDown
                      className={`w-3.5 h-3.5 transition-transform ${
                        activeMega === cat.id ? "rotate-180" : ""
                      }`}
                    />
                  </button>

                  {/* Mega Dropdown */}
                  <div className="mega-menu absolute top-full left-0 pt-2 w-[600px]">
                    <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
                      <div className="grid grid-cols-3 gap-0">
                        {/* Subcategories */}
                        <div className="col-span-2 p-5 grid grid-cols-2 gap-x-4 gap-y-5">
                          {cat.subcategories.map((sub) => (
                            <div key={sub.href}>
                              <Link
                                href={sub.href}
                                className="text-sm font-bold text-accent hover:text-brand-600 transition-colors mb-2 block font-bangla"
                              >
                                {sub.label}
                              </Link>
                              <ul className="space-y-1">
                                {sub.items.map((item) => (
                                  <li key={item}>
                                    <Link
                                      href={`${sub.href}?q=${item}`}
                                      className="text-xs text-gray-500 hover:text-brand-600 transition-colors flex items-center gap-1 font-bangla"
                                    >
                                      <ArrowRight className="w-3 h-3" />
                                      {item}
                                    </Link>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))}
                        </div>

                        {/* Banner */}
                        <div className={`bg-gradient-to-br ${cat.banner.color} p-5 flex flex-col justify-between`}>
                          <div>
                            <p className="text-white/80 text-xs font-bangla mb-1">{cat.featured}</p>
                            <p className="text-white font-bold text-lg font-display leading-tight">
                              {cat.banner.title}
                            </p>
                            <p className="text-white/90 text-sm mt-1 font-bangla">{cat.banner.subtitle}</p>
                          </div>
                          <Link
                            href={cat.href}
                            className="mt-4 bg-white/20 hover:bg-white/30 text-white text-xs font-semibold px-4 py-2 rounded-xl text-center transition-colors font-bangla"
                          >
                            সব দেখুন
                          </Link>
                        </div>
                      </div>

                      {/* Footer Link */}
                      <div className="border-t border-gray-100 px-5 py-3 flex items-center justify-between bg-gray-50">
                        <span className="text-xs text-gray-500 font-bangla">
                          সকল {cat.label} পণ্য দেখুন
                        </span>
                        <Link
                          href={cat.href}
                          className="text-xs font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1 font-bangla"
                        >
                          সব দেখুন <ArrowRight className="w-3 h-3" />
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              <Link
                href="/shop"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-100 font-bangla"
              >
                <TrendingUp className="w-4 h-4" />
                বেস্টসেলার
              </Link>
            </nav>

            {/* Right Side */}
            <div className="ml-auto flex items-center gap-2">
              {/* Search */}
              {searchOpen ? (
                <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2">
                  <Search className="w-4 h-4 text-gray-400" />
                  <input
                    ref={searchRef}
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="পণ্য খুঁজুন..."
                    className="bg-transparent text-sm outline-none w-40 font-bangla"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        window.location.href = `/shop?q=${searchQuery}`;
                      }
                    }}
                  />
                  <button onClick={() => setSearchOpen(false)}>
                    <X className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setSearchOpen(true)}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
                >
                  <Search className="w-5 h-5" />
                </button>
              )}

              {/* Wishlist */}
              <button className="hidden sm:flex p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
                <Heart className="w-5 h-5" />
              </button>

              {/* Cart */}
              <Link
                href="/checkout"
                className="relative p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
              >
                <ShoppingCart className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-brand-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Link>

              {/* Account */}
              <Link
                href="/account"
                className="hidden sm:flex p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
              >
                <User className="w-5 h-5" />
              </Link>

              {/* Mobile Menu */}
              <button
                className="lg:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-xl"
                onClick={() => setMobileOpen(!mobileOpen)}
              >
                {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-gray-100 bg-white mobile-menu-enter">
            <div className="max-w-7xl mx-auto px-4 py-4 space-y-1">
              {CATEGORIES.map((cat) => (
                <div key={cat.id}>
                  <button
                    onClick={() => setActiveMega(activeMega === cat.id ? null : cat.id)}
                    className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-3">
                      <span className={`p-1.5 rounded-lg ${cat.color}`}>
                        <cat.icon className="w-4 h-4" />
                      </span>
                      <span className="font-bangla">{cat.label}</span>
                    </div>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform ${
                        activeMega === cat.id ? "rotate-180" : ""
                      }`}
                    />
                  </button>

                  {activeMega === cat.id && (
                    <div className="ml-4 pl-4 border-l-2 border-brand-100 space-y-1 mt-1 mb-2">
                      {cat.subcategories.map((sub) => (
                        <div key={sub.href}>
                          <Link
                            href={sub.href}
                            className="block px-3 py-2 text-sm font-semibold text-accent hover:text-brand-600 font-bangla"
                          >
                            {sub.label}
                          </Link>
                          <div className="flex flex-wrap gap-2 px-3 pb-2">
                            {sub.items.map((item) => (
                              <Link
                                key={item}
                                href={`${sub.href}?q=${item}`}
                                className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-lg hover:bg-brand-50 hover:text-brand-700 font-bangla"
                              >
                                {item}
                              </Link>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              <div className="pt-3 border-t border-gray-100 space-y-2">
                <Link href="/order-tracking" className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-gray-700 hover:bg-gray-50">
                  <Tag className="w-4 h-4 text-brand-500" />
                  <span className="font-bangla">অর্ডার ট্র্যাক করুন</span>
                </Link>
                <div className="px-4 py-2 text-xs text-gray-400 font-bangla">
                  📦 ঢাকায় ৳৮০ | সারা বাংলাদেশ ৳১৫০
                </div>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
