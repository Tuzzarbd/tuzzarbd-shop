// src/components/ui/MetaPixelInit.tsx
"use client";
import { useEffect } from "react";
import { MetaPixel } from "@/lib/tracking";
export default function MetaPixelInit({ event }: { event: string }) {
  useEffect(() => {
    if (event === "PageView") MetaPixel.pageView();
  }, [event]);
  return null;
}
