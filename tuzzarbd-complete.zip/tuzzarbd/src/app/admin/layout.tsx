// src/app/admin/layout.tsx
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard, Package, Tags, ShoppingCart, BarChart3,
  Warehouse, Ticket, Star, AlertCircle, FileText, Settings,
  LogOut, Menu, X, Bell, ChevronDown, TrendingUp, Users,
  ShoppingBag
} from "lucide-react";
import Image from "next/image";

const NAV_ITEMS = [
  {
    group: "মূল",
    items: [
      { href: "/admin/dashboard", label: "ড্যাশবোর্ড", icon: LayoutDashboard },
      { href: "/admin/analytics", label: "বিশ্লেষণ", icon: BarChart3 },
    ],
  },
  {
    group: "ক্যাটালগ",
    items: [
      { href: "/admin/products", label: "পণ্য", icon: Package },
      { href: "/admin/categories", label: "ক্যাটাগরি", icon: Tags },
    ],
  },
  {
    group: "অর্ডার",
    items: [
      { href: "/admin/orders", label: "অর্ডার", icon: ShoppingCart },
      { href: "/admin/abandoned-carts", label: "পরিত্যক্ত কার্ট", icon: AlertCircle },
    ],
  },
  {
    group: "পরিচালনা",
    items: [
      { href: "/admin/inventory", label: "ইনভেন্টরি", icon: Warehouse },
      { href: "/admin/coupons", label: "কুপন", icon: Ticket },
      { href: "/admin/reviews", label: "রিভিউ", icon: Star },
      { href: "/admin/customers", label: "কাস্টমার", icon: Users },
    ],
  },
  {
    group: "সিস্টেম",
    items: [
      { href: "/admin/settings", label: "সেটিংস", icon: Settings },
    ],
  },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState(3);

  // Don't show layout on login page
  if (pathname === "/admin/login") {
    return <>{children}</>;
  }

  const handleLogout = async () => {
    await fetch("/api/admin/auth/logout", { method: "POST" });
    router.push("/admin/login");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside
        className={`
          fixed inset-y-0 left-0 z-50 bg-white border-r border-gray-100 shadow-sm
          transition-all duration-300 ease-in-out
          ${sidebarOpen ? "w-64" : "w-16"}
          ${mobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
        `}
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-100">
          {sidebarOpen ? (
            <Link href="/admin/dashboard" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-lg text-accent">
                tuzzarbd
              </span>
              <span className="text-xs bg-brand-100 text-brand-700 px-1.5 py-0.5 rounded font-semibold">
                Admin
              </span>
            </Link>
          ) : (
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center mx-auto">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
          )}
        </div>

        {/* Nav Items */}
        <nav className="p-3 space-y-6 overflow-y-auto h-[calc(100vh-4rem-4rem)]">
          {NAV_ITEMS.map((group) => (
            <div key={group.group}>
              {sidebarOpen && (
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 mb-2 font-bangla">
                  {group.group}
                </p>
              )}
              <div className="space-y-1">
                {group.items.map((item) => {
                  const active = pathname.startsWith(item.href);
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={active ? "admin-nav-item-active" : "admin-nav-item-inactive"}
                      title={!sidebarOpen ? item.label : undefined}
                    >
                      <Icon className="w-5 h-5 flex-shrink-0" />
                      {sidebarOpen && (
                        <span className="font-bangla">{item.label}</span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Sidebar Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-gray-100 bg-white">
          <button
            onClick={handleLogout}
            className="admin-nav-item-inactive w-full justify-center lg:justify-start"
          >
            <LogOut className="w-5 h-5 flex-shrink-0 text-red-500" />
            {sidebarOpen && (
              <span className="text-red-500 font-bangla">লগআউট</span>
            )}
          </button>
        </div>
      </aside>

      {/* Mobile Overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Main Content */}
      <div
        className={`
          flex-1 flex flex-col min-h-screen transition-all duration-300
          ${sidebarOpen ? "lg:ml-64" : "lg:ml-16"}
        `}
      >
        {/* Top Bar */}
        <header className="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-4 lg:px-6 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            {/* Mobile Menu Toggle */}
            <button
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>

            {/* Desktop Sidebar Toggle */}
            <button
              className="hidden lg:flex p-2 rounded-lg hover:bg-gray-100"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="w-5 h-5 text-gray-600" />
            </button>

            {/* Breadcrumb */}
            <div className="hidden md:flex items-center gap-2 text-sm text-gray-500">
              <span className="font-bangla">Admin Panel</span>
              <span>/</span>
              <span className="text-gray-900 font-medium capitalize font-bangla">
                {pathname.split("/").pop()?.replace(/-/g, " ")}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Notification Bell */}
            <button className="relative p-2 rounded-lg hover:bg-gray-100">
              <Bell className="w-5 h-5 text-gray-600" />
              {notifications > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                  {notifications}
                </span>
              )}
            </button>

            {/* View Store */}
            <Link
              href="/"
              target="_blank"
              className="hidden md:flex items-center gap-2 text-sm font-medium text-brand-600 hover:text-brand-700 bg-brand-50 px-3 py-1.5 rounded-lg"
            >
              <TrendingUp className="w-4 h-4" />
              স্টোর দেখুন
            </Link>

            {/* Admin Avatar */}
            <button className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-gray-100">
              <div className="w-8 h-8 bg-brand-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                A
              </div>
              <ChevronDown className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
