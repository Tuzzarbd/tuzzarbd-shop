// src/app/admin/products/page.tsx
"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Plus, Search, Filter, Edit, Trash2, Eye, ChevronLeft,
  ChevronRight, Package, AlertTriangle, MoreVertical,
  Download, Upload, RefreshCw, Star, TrendingUp
} from "lucide-react";

interface Product {
  id: string;
  name: string;
  slug: string;
  price: number;
  comparePrice?: number;
  stock: number;
  category: { name: string; type: string };
  isActive: boolean;
  isFeatured: boolean;
  totalSold: number;
  avgRating: number;
  images: { url: string }[];
  createdAt: string;
}

const CATEGORY_COLORS: Record<string, string> = {
  FASHION: "bg-pink-100 text-pink-800",
  GADGETS: "bg-blue-100 text-blue-800",
  BEAUTY: "bg-purple-100 text-purple-800",
};

const CATEGORY_LABELS: Record<string, string> = {
  FASHION: "ফ্যাশন",
  GADGETS: "গ্যাজেট",
  BEAUTY: "বিউটি",
};

// Sample data
const SAMPLE_PRODUCTS: Product[] = [
  {
    id: "1",
    name: "প্রিমিয়াম কটন শার্ট - Navy Blue",
    slug: "premium-cotton-shirt-navy",
    price: 850,
    comparePrice: 1200,
    stock: 45,
    category: { name: "পুরুষ পোশাক", type: "FASHION" },
    isActive: true,
    isFeatured: true,
    totalSold: 128,
    avgRating: 4.5,
    images: [{ url: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=100&h=100&fit=crop" }],
    createdAt: "2024-01-15",
  },
  {
    id: "2",
    name: "Samsung Galaxy Buds 2 Pro",
    slug: "samsung-galaxy-buds-2-pro",
    price: 12500,
    comparePrice: 15000,
    stock: 3,
    category: { name: "ইয়ারফোন", type: "GADGETS" },
    isActive: true,
    isFeatured: false,
    totalSold: 52,
    avgRating: 4.8,
    images: [{ url: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=100&h=100&fit=crop" }],
    createdAt: "2024-02-20",
  },
  {
    id: "3",
    name: "ভিটামিন C ফেসওয়াশ (100ml)",
    slug: "vitamin-c-facewash",
    price: 350,
    stock: 0,
    category: { name: "স্কিনকেয়ার", type: "BEAUTY" },
    isActive: false,
    isFeatured: false,
    totalSold: 234,
    avgRating: 4.3,
    images: [{ url: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=100&h=100&fit=crop" }],
    createdAt: "2024-01-08",
  },
  {
    id: "4",
    name: "ফ্লোরাল প্রিন্ট শাড়ি",
    slug: "floral-print-saree",
    price: 2200,
    comparePrice: 2800,
    stock: 18,
    category: { name: "শাড়ি", type: "FASHION" },
    isActive: true,
    isFeatured: true,
    totalSold: 89,
    avgRating: 4.7,
    images: [{ url: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=100&h=100&fit=crop" }],
    createdAt: "2024-03-01",
  },
  {
    id: "5",
    name: "Xiaomi Redmi Note 13 Pro",
    slug: "xiaomi-redmi-note-13-pro",
    price: 32000,
    comparePrice: 35000,
    stock: 12,
    category: { name: "স্মার্টফোন", type: "GADGETS" },
    isActive: true,
    isFeatured: true,
    totalSold: 67,
    avgRating: 4.6,
    images: [{ url: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=100&h=100&fit=crop" }],
    createdAt: "2024-02-10",
  },
];

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>(SAMPLE_PRODUCTS);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [page, setPage] = useState(1);
  const PER_PAGE = 20;

  const filtered = products.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === "ALL" || p.category.type === categoryFilter;
    const matchStatus =
      statusFilter === "ALL" ||
      (statusFilter === "ACTIVE" && p.isActive) ||
      (statusFilter === "INACTIVE" && !p.isActive) ||
      (statusFilter === "LOW_STOCK" && p.stock <= 5 && p.stock > 0) ||
      (statusFilter === "OUT" && p.stock === 0);
    return matchSearch && matchCat && matchStatus;
  });

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleAll = () => {
    setSelectedIds(
      selectedIds.length === filtered.length ? [] : filtered.map((p) => p.id)
    );
  };

  const handleDelete = async (id: string) => {
    if (!confirm("এই পণ্যটি মুছে ফেলতে চান?")) return;
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const handleBulkDelete = async () => {
    if (!confirm(`${selectedIds.length}টি পণ্য মুছে ফেলতে চান?`)) return;
    setProducts((prev) => prev.filter((p) => !selectedIds.includes(p.id)));
    setSelectedIds([]);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-accent font-display">পণ্য</h1>
          <p className="text-sm text-gray-500 font-bangla mt-1">
            {products.length}টি পণ্য মোট
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="flex items-center gap-2 text-sm border border-gray-200 bg-white px-4 py-2 rounded-xl hover:bg-gray-50">
            <Upload className="w-4 h-4" />
            <span className="hidden sm:inline">CSV আমদানি</span>
          </button>
          <button className="flex items-center gap-2 text-sm border border-gray-200 bg-white px-4 py-2 rounded-xl hover:bg-gray-50">
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">এক্সপোর্ট</span>
          </button>
          <Link
            href="/admin/products/new"
            className="btn-primary flex items-center gap-2 text-sm py-2"
          >
            <Plus className="w-4 h-4" />
            নতুন পণ্য
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="পণ্য খুঁজুন..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input pl-9 text-sm"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="input text-sm w-auto min-w-36"
        >
          <option value="ALL">সব ক্যাটাগরি</option>
          <option value="FASHION">ফ্যাশন</option>
          <option value="GADGETS">গ্যাজেট</option>
          <option value="BEAUTY">বিউটি</option>
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="input text-sm w-auto min-w-36"
        >
          <option value="ALL">সব স্ট্যাটাস</option>
          <option value="ACTIVE">সক্রিয়</option>
          <option value="INACTIVE">নিষ্ক্রিয়</option>
          <option value="LOW_STOCK">কম স্টক</option>
          <option value="OUT">স্টক শেষ</option>
        </select>
      </div>

      {/* Bulk Actions */}
      {selectedIds.length > 0 && (
        <div className="bg-brand-50 border border-brand-200 rounded-xl px-4 py-3 flex items-center justify-between">
          <span className="text-sm font-medium text-brand-800 font-bangla">
            {selectedIds.length}টি পণ্য নির্বাচিত
          </span>
          <div className="flex gap-2">
            <button className="text-sm text-blue-600 font-medium hover:underline">
              সক্রিয় করুন
            </button>
            <button className="text-sm text-gray-600 font-medium hover:underline">
              নিষ্ক্রিয় করুন
            </button>
            <button
              onClick={handleBulkDelete}
              className="text-sm text-red-600 font-medium hover:underline"
            >
              মুছুন
            </button>
          </div>
        </div>
      )}

      {/* Products Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                <th className="w-10">
                  <input
                    type="checkbox"
                    checked={selectedIds.length === filtered.length && filtered.length > 0}
                    onChange={toggleAll}
                    className="rounded"
                  />
                </th>
                <th>পণ্য</th>
                <th>ক্যাটাগরি</th>
                <th>মূল্য</th>
                <th>স্টক</th>
                <th>বিক্রয়</th>
                <th>রেটিং</th>
                <th>স্ট্যাটাস</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((product) => (
                <tr key={product.id}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(product.id)}
                      onChange={() => toggleSelect(product.id)}
                      className="rounded"
                    />
                  </td>
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                        {product.images[0] ? (
                          <img
                            src={product.images[0].url}
                            alt={product.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="w-5 h-5 text-gray-400" />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 font-bangla text-sm leading-snug max-w-48 truncate">
                          {product.name}
                        </p>
                        {product.isFeatured && (
                          <span className="badge-brand text-xs">ফিচার্ড</span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`badge text-xs ${CATEGORY_COLORS[product.category.type]}`}>
                      {CATEGORY_LABELS[product.category.type]}
                    </span>
                    <p className="text-xs text-gray-400 mt-1 font-bangla">{product.category.name}</p>
                  </td>
                  <td>
                    <p className="font-bold text-accent">৳{product.price.toLocaleString()}</p>
                    {product.comparePrice && (
                      <p className="text-xs text-gray-400 line-through">
                        ৳{product.comparePrice.toLocaleString()}
                      </p>
                    )}
                  </td>
                  <td>
                    {product.stock === 0 ? (
                      <span className="badge-danger">স্টক শেষ</span>
                    ) : product.stock <= 5 ? (
                      <span className="badge-warning flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        {product.stock}
                      </span>
                    ) : (
                      <span className="font-semibold text-gray-700">{product.stock}</span>
                    )}
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-gray-700">
                      <TrendingUp className="w-3 h-3 text-green-500" />
                      <span className="font-semibold">{product.totalSold}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span className="text-sm font-semibold">{product.avgRating}</span>
                    </div>
                  </td>
                  <td>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={product.isActive}
                        onChange={() =>
                          setProducts((prev) =>
                            prev.map((p) =>
                              p.id === product.id ? { ...p, isActive: !p.isActive } : p
                            )
                          )
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-brand-500" />
                    </label>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <Link
                        href={`/product/${product.slug}`}
                        target="_blank"
                        className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
                      >
                        <Eye className="w-4 h-4" />
                      </Link>
                      <Link
                        href={`/admin/products/${product.id}/edit`}
                        className="p-1.5 text-blue-400 hover:text-blue-700 hover:bg-blue-50 rounded-lg"
                      >
                        <Edit className="w-4 h-4" />
                      </Link>
                      <button
                        onClick={() => handleDelete(product.id)}
                        className="p-1.5 text-red-400 hover:text-red-700 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-4 border-t border-gray-100 flex items-center justify-between text-sm">
          <span className="text-gray-500 font-bangla">
            {filtered.length}টির মধ্যে {Math.min(page * PER_PAGE, filtered.length)}টি দেখানো হচ্ছে
          </span>
          <div className="flex gap-2">
            <button
              className="p-2 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-40"
              disabled={page === 1}
              onClick={() => setPage((p) => p - 1)}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              className="p-2 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-40"
              disabled={page * PER_PAGE >= filtered.length}
              onClick={() => setPage((p) => p + 1)}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
