// src/app/admin/orders/page.tsx
"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Search, Filter, Eye, Printer, Download, ChevronLeft,
  ChevronRight, Clock, CheckCircle, Truck, XCircle,
  RefreshCw, Package, Phone, MapPin, FileText, ArrowUpDown
} from "lucide-react";

interface Order {
  id: string;
  orderNumber: string;
  customer: string;
  phone: string;
  district: string;
  upazila: string;
  items: number;
  subtotal: number;
  shipping: number;
  total: number;
  paymentMethod: string;
  status: string;
  isDhaka: boolean;
  createdAt: string;
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  PENDING: { label: "অপেক্ষমান", color: "bg-amber-100 text-amber-800", icon: Clock },
  CONFIRMED: { label: "নিশ্চিত", color: "bg-blue-100 text-blue-800", icon: CheckCircle },
  PROCESSING: { label: "প্রক্রিয়াধীন", color: "bg-purple-100 text-purple-800", icon: RefreshCw },
  SHIPPED: { label: "শিপড", color: "bg-indigo-100 text-indigo-800", icon: Truck },
  DELIVERED: { label: "ডেলিভার্ড", color: "bg-green-100 text-green-800", icon: CheckCircle },
  CANCELLED: { label: "বাতিল", color: "bg-red-100 text-red-800", icon: XCircle },
};

const PAYMENT_LABELS: Record<string, string> = {
  COD: "ক্যাশ অন ডেলিভারি",
  BKASH: "bKash",
  NAGAD: "Nagad",
  ROCKET: "Rocket",
};

const SAMPLE_ORDERS: Order[] = [
  {
    id: "1",
    orderNumber: "TZ-LPK3C-7M2N",
    customer: "রহিম উদ্দিন",
    phone: "01712345678",
    district: "Dhaka",
    upazila: "Mirpur",
    items: 3,
    subtotal: 2500,
    shipping: 80,
    total: 2580,
    paymentMethod: "COD",
    status: "PENDING",
    isDhaka: true,
    createdAt: "2024-03-15 10:30",
  },
  {
    id: "2",
    orderNumber: "TZ-LPK4D-8N3O",
    customer: "সুমাইয়া খাতুন",
    phone: "01987654321",
    district: "Chittagong",
    upazila: "Hathazari",
    items: 1,
    subtotal: 12500,
    shipping: 150,
    total: 12650,
    paymentMethod: "BKASH",
    status: "CONFIRMED",
    isDhaka: false,
    createdAt: "2024-03-15 09:15",
  },
  {
    id: "3",
    orderNumber: "TZ-LPK5E-9O4P",
    customer: "আব্দুল করিম",
    phone: "01611223344",
    district: "Gazipur",
    upazila: "Tongi",
    items: 2,
    subtotal: 1800,
    shipping: 80,
    total: 1880,
    paymentMethod: "NAGAD",
    status: "SHIPPED",
    isDhaka: true,
    createdAt: "2024-03-14 16:45",
  },
];

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>(SAMPLE_ORDERS);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [page, setPage] = useState(1);

  const filtered = orders.filter((o) => {
    const matchSearch =
      o.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
      o.customer.toLowerCase().includes(search.toLowerCase()) ||
      o.phone.includes(search);
    const matchStatus = statusFilter === "ALL" || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const updateStatus = (id: string, status: string) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, status } : o))
    );
  };

  const handleBulkPrint = () => {
    alert(`${selectedIds.length}টি শিপিং লেবেল প্রিন্ট হচ্ছে...`);
  };

  const handleCSVExport = () => {
    const csv = [
      ["Order #", "Customer", "Phone", "District", "Items", "Total", "Status", "Date"],
      ...filtered.map((o) => [
        o.orderNumber, o.customer, o.phone, o.district,
        o.items, o.total, o.status, o.createdAt
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `orders-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-accent font-display">অর্ডার</h1>
          <p className="text-sm text-gray-500 font-bangla mt-1">
            {filtered.length}টি অর্ডার
          </p>
        </div>
        <div className="flex gap-2">
          {selectedIds.length > 0 && (
            <>
              <button
                onClick={handleBulkPrint}
                className="flex items-center gap-2 text-sm border border-gray-200 bg-white px-4 py-2 rounded-xl hover:bg-gray-50"
              >
                <Printer className="w-4 h-4" />
                লেবেল প্রিন্ট ({selectedIds.length})
              </button>
            </>
          )}
          <button
            onClick={handleCSVExport}
            className="flex items-center gap-2 text-sm border border-gray-200 bg-white px-4 py-2 rounded-xl hover:bg-gray-50"
          >
            <Download className="w-4 h-4" />
            CSV এক্সপোর্ট
          </button>
        </div>
      </div>

      {/* Status Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {[
          { key: "ALL", label: "সব", count: orders.length },
          ...Object.entries(STATUS_CONFIG).map(([key, cfg]) => ({
            key,
            label: cfg.label,
            count: orders.filter((o) => o.status === key).length,
          })),
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setStatusFilter(tab.key)}
            className={`flex-shrink-0 text-sm px-4 py-2 rounded-xl font-bangla font-medium transition-all ${
              statusFilter === tab.key
                ? "bg-brand-500 text-white shadow-brand"
                : "bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
            }`}
          >
            {tab.label}
            {tab.count > 0 && (
              <span className="ml-2 text-xs bg-white/20 px-1.5 py-0.5 rounded-full">
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          placeholder="অর্ডার নম্বর, নাম, বা ফোন দিয়ে খুঁজুন..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input pl-9 text-sm"
        />
      </div>

      {/* Bulk selection info */}
      {selectedIds.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-3 flex items-center justify-between text-sm">
          <span className="font-bangla text-blue-800">{selectedIds.length}টি অর্ডার নির্বাচিত</span>
          <div className="flex gap-3">
            {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
              <button
                key={key}
                onClick={() => {
                  selectedIds.forEach((id) => updateStatus(id, key));
                  setSelectedIds([]);
                }}
                className="text-blue-600 hover:underline font-medium"
              >
                {cfg.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Orders Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                <th className="w-10">
                  <input
                    type="checkbox"
                    checked={selectedIds.length === filtered.length && filtered.length > 0}
                    onChange={() =>
                      setSelectedIds(
                        selectedIds.length === filtered.length ? [] : filtered.map((o) => o.id)
                      )
                    }
                    className="rounded"
                  />
                </th>
                <th>অর্ডার</th>
                <th>কাস্টমার</th>
                <th>ঠিকানা</th>
                <th>পণ্য</th>
                <th>মোট</th>
                <th>পেমেন্ট</th>
                <th>স্ট্যাটাস</th>
                <th>তারিখ</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((order) => {
                const StatusIcon = STATUS_CONFIG[order.status]?.icon || Clock;
                return (
                  <tr key={order.id}>
                    <td>
                      <input
                        type="checkbox"
                        checked={selectedIds.includes(order.id)}
                        onChange={() =>
                          setSelectedIds((prev) =>
                            prev.includes(order.id)
                              ? prev.filter((x) => x !== order.id)
                              : [...prev, order.id]
                          )
                        }
                        className="rounded"
                      />
                    </td>
                    <td>
                      <Link
                        href={`/admin/orders/${order.id}`}
                        className="font-mono text-brand-600 hover:underline font-bold text-xs"
                      >
                        #{order.orderNumber}
                      </Link>
                    </td>
                    <td>
                      <p className="font-medium text-gray-900 font-bangla text-sm">{order.customer}</p>
                      <div className="flex items-center gap-1 text-xs text-gray-400 mt-0.5">
                        <Phone className="w-3 h-3" />
                        {order.phone}
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center gap-1 text-xs text-gray-600">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        <span className="font-bangla">{order.upazila}, {order.district}</span>
                      </div>
                      <span className={`text-xs font-semibold ${order.isDhaka ? "text-green-600" : "text-orange-600"}`}>
                        {order.isDhaka ? "ঢাকার ভেতরে" : "ঢাকার বাইরে"}
                      </span>
                    </td>
                    <td className="text-center">
                      <span className="font-semibold">{order.items}</span>
                      <span className="text-xs text-gray-400 font-bangla"> টি</span>
                    </td>
                    <td>
                      <p className="font-bold text-accent">৳{order.total.toLocaleString()}</p>
                      <p className="text-xs text-gray-400 font-bangla">
                        শিপিং: ৳{order.shipping}
                      </p>
                    </td>
                    <td>
                      <span className="badge bg-gray-100 text-gray-700 text-xs font-bangla">
                        {PAYMENT_LABELS[order.paymentMethod] || order.paymentMethod}
                      </span>
                    </td>
                    <td>
                      <select
                        value={order.status}
                        onChange={(e) => updateStatus(order.id, e.target.value)}
                        className={`text-xs px-2 py-1 rounded-lg border-0 font-semibold cursor-pointer font-bangla ${STATUS_CONFIG[order.status]?.color}`}
                      >
                        {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
                          <option key={key} value={key}>{cfg.label}</option>
                        ))}
                      </select>
                    </td>
                    <td className="text-xs text-gray-400 font-bangla whitespace-nowrap">{order.createdAt}</td>
                    <td>
                      <div className="flex items-center gap-1">
                        <Link
                          href={`/admin/orders/${order.id}`}
                          className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
                        >
                          <Eye className="w-4 h-4" />
                        </Link>
                        <button className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                          <Printer className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                          <FileText className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 text-gray-400">
            <Package className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-bangla">কোনো অর্ডার পাওয়া যায়নি</p>
          </div>
        )}

        {/* Pagination */}
        <div className="p-4 border-t border-gray-100 flex items-center justify-between text-sm">
          <span className="text-gray-500 font-bangla">
            {filtered.length}টি অর্ডার দেখানো হচ্ছে
          </span>
          <div className="flex gap-2">
            <button className="p-2 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-40" disabled>
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-3 py-1.5 bg-brand-500 text-white rounded-lg text-sm font-bold">1</span>
            <button className="p-2 border border-gray-200 rounded-lg hover:bg-gray-50">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
