// src/app/admin/dashboard/page.tsx
"use client";

import { useState, useEffect } from "react";
import {
  TrendingUp, ShoppingCart, Package, Users, AlertTriangle,
  ArrowUpRight, ArrowDownRight, RefreshCw, Eye, DollarSign,
  Clock, CheckCircle, XCircle, Truck, RotateCcw
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, Legend
} from "recharts";
import { formatCurrency } from "@/lib/db";
import Link from "next/link";

// Mock data for demo - in production, fetch from API
const MOCK_REVENUE_DATA = [
  { date: "Jan", revenue: 45000, orders: 12 },
  { date: "Feb", revenue: 62000, orders: 18 },
  { date: "Mar", revenue: 58000, orders: 15 },
  { date: "Apr", revenue: 89000, orders: 24 },
  { date: "May", revenue: 97000, orders: 28 },
  { date: "Jun", revenue: 115000, orders: 32 },
  { date: "Jul", revenue: 134000, orders: 38 },
];

const CATEGORY_DATA = [
  { name: "Fashion", value: 42, color: "#f97316" },
  { name: "Gadgets", value: 35, color: "#1a1a2e" },
  { name: "Beauty", value: 23, color: "#ec4899" },
];

const RECENT_ORDERS = [
  { id: "TZ-001", customer: "রহিম খান", phone: "01712345678", amount: 2500, status: "DELIVERED", time: "2 ঘণ্টা আগে" },
  { id: "TZ-002", customer: "সুমাইয়া বেগম", phone: "01987654321", amount: 1800, status: "PROCESSING", time: "3 ঘণ্টা আগে" },
  { id: "TZ-003", customer: "করিম আহমেদ", phone: "01611223344", amount: 4200, status: "PENDING", time: "5 ঘণ্টা আগে" },
  { id: "TZ-004", customer: "ফারিয়া ইসলাম", phone: "01855443322", amount: 950, status: "SHIPPED", time: "গতকাল" },
  { id: "TZ-005", customer: "তানভীর হোসেন", phone: "01733221100", amount: 3300, status: "CONFIRMED", time: "গতকাল" },
];

const LOW_STOCK_ITEMS = [
  { name: "Samsung Galaxy Watch 6", stock: 2, category: "Gadgets" },
  { name: "নিম ফেস ওয়াশ (200ml)", stock: 3, category: "Beauty" },
  { name: "কটন টি-শার্ট (L) - সাদা", stock: 4, category: "Fashion" },
];

const STATUS_COLORS: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-800",
  CONFIRMED: "bg-blue-100 text-blue-800",
  PROCESSING: "bg-purple-100 text-purple-800",
  SHIPPED: "bg-indigo-100 text-indigo-800",
  DELIVERED: "bg-green-100 text-green-800",
  CANCELLED: "bg-red-100 text-red-800",
};

const STATUS_LABELS: Record<string, string> = {
  PENDING: "অপেক্ষমান",
  CONFIRMED: "নিশ্চিত",
  PROCESSING: "প্রক্রিয়াধীন",
  SHIPPED: "শিপড",
  DELIVERED: "ডেলিভার্ড",
  CANCELLED: "বাতিল",
};

interface StatCardProps {
  title: string;
  value: string;
  change: number;
  icon: React.ElementType;
  color: string;
  prefix?: string;
}

function StatCard({ title, value, change, icon: Icon, color, prefix }: StatCardProps) {
  const isPositive = change >= 0;
  return (
    <div className="stat-card">
      <div>
        <p className="text-sm font-medium text-gray-500 font-bangla">{title}</p>
        <p className="text-2xl font-bold text-accent mt-1 font-display">
          {prefix}{value}
        </p>
        <div className={`flex items-center gap-1 mt-2 text-xs font-semibold ${isPositive ? "text-green-600" : "text-red-500"}`}>
          {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
          <span>{Math.abs(change)}% গত মাস থেকে</span>
        </div>
      </div>
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon className="w-6 h-6" />
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    revenue: "4,82,000",
    orders: "147",
    products: "84",
    customers: "312",
  });
  const [loading, setLoading] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-accent font-display">ড্যাশবোর্ড</h1>
          <p className="text-sm text-gray-500 font-bangla mt-1">আপনার স্টোরের সার্বিক অবস্থা</p>
        </div>
        <button
          onClick={() => setLoading(true)}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 bg-white border border-gray-200 px-4 py-2 rounded-xl hover:bg-gray-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          রিফ্রেশ
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          title="মোট রাজস্ব"
          value={stats.revenue}
          change={18.5}
          icon={DollarSign}
          color="bg-brand-100 text-brand-700"
          prefix="৳"
        />
        <StatCard
          title="মোট অর্ডার"
          value={stats.orders}
          change={12.3}
          icon={ShoppingCart}
          color="bg-blue-100 text-blue-700"
        />
        <StatCard
          title="মোট পণ্য"
          value={stats.products}
          change={5.1}
          icon={Package}
          color="bg-purple-100 text-purple-700"
        />
        <StatCard
          title="কাস্টমার"
          value={stats.customers}
          change={24.8}
          icon={Users}
          color="bg-green-100 text-green-700"
        />
      </div>

      {/* Quick Order Status */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: "অপেক্ষমান", count: 12, icon: Clock, color: "text-amber-600 bg-amber-50 border-amber-200" },
          { label: "নিশ্চিত", count: 8, icon: CheckCircle, color: "text-blue-600 bg-blue-50 border-blue-200" },
          { label: "প্রক্রিয়াধীন", count: 15, icon: RefreshCw, color: "text-purple-600 bg-purple-50 border-purple-200" },
          { label: "শিপড", count: 23, icon: Truck, color: "text-indigo-600 bg-indigo-50 border-indigo-200" },
          { label: "ডেলিভার্ড", count: 85, icon: CheckCircle, color: "text-green-600 bg-green-50 border-green-200" },
          { label: "বাতিল", count: 4, icon: XCircle, color: "text-red-600 bg-red-50 border-red-200" },
        ].map((item) => (
          <Link
            href={`/admin/orders?status=${item.label}`}
            key={item.label}
            className={`border rounded-xl p-3 flex flex-col items-center gap-1 hover:shadow-sm transition-shadow ${item.color}`}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-2xl font-bold">{item.count}</span>
            <span className="text-xs font-medium font-bangla">{item.label}</span>
          </Link>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 card p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-semibold text-accent font-display">রাজস্ব ট্রেন্ড</h2>
              <p className="text-xs text-gray-500 font-bangla">গত ৭ মাস</p>
            </div>
            <div className="flex gap-2">
              {["সাপ্তাহিক", "মাসিক", "বার্ষিক"].map((t) => (
                <button
                  key={t}
                  className="text-xs px-3 py-1 rounded-lg font-bangla font-medium bg-gray-100 text-gray-600 hover:bg-brand-50 hover:text-brand-700"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={MOCK_REVENUE_DATA}>
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `৳${v / 1000}k`} />
              <Tooltip
                formatter={(value) => [`৳${Number(value).toLocaleString()}`, "রাজস্ব"]}
                contentStyle={{ borderRadius: "12px", border: "none", boxShadow: "0 4px 20px rgba(0,0,0,0.1)" }}
              />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="#f97316"
                strokeWidth={2.5}
                fill="url(#revenueGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Category Breakdown */}
        <div className="card p-6">
          <h2 className="font-semibold text-accent mb-2 font-display">ক্যাটাগরি বিভাজন</h2>
          <p className="text-xs text-gray-500 font-bangla mb-4">বিক্রয় অনুযায়ী</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie
                data={CATEGORY_DATA}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={4}
                dataKey="value"
              >
                {CATEGORY_DATA.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value}%`, "শেয়ার"]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-3 mt-4">
            {CATEGORY_DATA.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full" style={{ background: item.color }} />
                  <span className="text-gray-700">{item.name}</span>
                </div>
                <span className="font-bold text-accent">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <div className="lg:col-span-2 card overflow-hidden">
          <div className="p-5 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold text-accent font-display">সাম্প্রতিক অর্ডার</h2>
            <Link
              href="/admin/orders"
              className="text-sm text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1"
            >
              সব দেখুন <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>অর্ডার</th>
                  <th>কাস্টমার</th>
                  <th>পরিমাণ</th>
                  <th>স্ট্যাটাস</th>
                  <th>সময়</th>
                </tr>
              </thead>
              <tbody>
                {RECENT_ORDERS.map((order) => (
                  <tr key={order.id}>
                    <td>
                      <Link
                        href={`/admin/orders/${order.id}`}
                        className="font-mono text-brand-600 hover:underline font-medium text-xs"
                      >
                        #{order.id}
                      </Link>
                    </td>
                    <td>
                      <div>
                        <p className="font-medium text-gray-900 font-bangla text-sm">{order.customer}</p>
                        <p className="text-xs text-gray-400">{order.phone}</p>
                      </div>
                    </td>
                    <td className="font-bold text-accent">৳{order.amount.toLocaleString()}</td>
                    <td>
                      <span className={`badge text-xs ${STATUS_COLORS[order.status]}`}>
                        {STATUS_LABELS[order.status]}
                      </span>
                    </td>
                    <td className="text-gray-400 text-xs font-bangla">{order.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Low Stock Alert */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 bg-red-100 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h2 className="font-semibold text-accent font-display">লো স্টক সতর্কতা</h2>
              <p className="text-xs text-gray-500 font-bangla">৫ এর নিচে স্টক</p>
            </div>
          </div>
          <div className="space-y-3">
            {LOW_STOCK_ITEMS.map((item, i) => (
              <div key={i} className="flex items-start justify-between p-3 bg-red-50 rounded-xl border border-red-100">
                <div>
                  <p className="text-sm font-medium text-gray-900 font-bangla leading-snug">{item.name}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{item.category}</p>
                </div>
                <span className="badge-danger ml-2 flex-shrink-0">
                  {item.stock} বাকি
                </span>
              </div>
            ))}
          </div>
          <Link
            href="/admin/inventory"
            className="mt-4 w-full btn-secondary text-sm py-2 flex items-center justify-center gap-2"
          >
            ইনভেন্টরি পরিচালনা করুন
          </Link>
        </div>
      </div>
    </div>
  );
}
