// src/app/layout.tsx
import type { Metadata, Viewport } from "next";
import "../styles/globals.css";
import { Toaster } from "react-hot-toast";
import MetaPixelScript from "@/components/ui/MetaPixelScript";

const SITE_NAME = "tuzzarbd";
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://tuzzarbd.com";
const META_DESCRIPTION = "Bangladesh's premier multi-niche store — Fashion, Smart Gadgets & Beauty Care. Fast delivery across Bangladesh. ৳80 Dhaka | ৳150 Outside Dhaka.";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: `${SITE_NAME} — Fashion, Gadgets & Beauty`,
    template: `%s | ${SITE_NAME}`,
  },
  description: META_DESCRIPTION,
  keywords: ["online shopping bangladesh", "fashion", "gadgets", "beauty care", "tuzzarbd", "বাংলাদেশ অনলাইন শপ"],
  authors: [{ name: "tuzzarbd" }],
  creator: "tuzzarbd",
  openGraph: {
    type: "website",
    siteName: SITE_NAME,
    title: `${SITE_NAME} — Fashion, Gadgets & Beauty`,
    description: META_DESCRIPTION,
    url: SITE_URL,
    images: [
      {
        url: `/og-image.jpg`,
        width: 1200,
        height: 630,
        alt: "tuzzarbd Store",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: `${SITE_NAME} — Fashion, Gadgets & Beauty`,
    description: META_DESCRIPTION,
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#f97316",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <head>
        {/* Google Fonts */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        
        {/* JSON-LD Organization Schema */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "tuzzarbd",
              url: SITE_URL,
              logo: `${SITE_URL}/logo.png`,
              contactPoint: {
                "@type": "ContactPoint",
                telephone: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER,
                contactType: "customer service",
                availableLanguage: ["Bengali", "English"],
              },
              sameAs: [
                `https://facebook.com/${process.env.NEXT_PUBLIC_FB_PAGE || "tuzzarbd"}`,
              ],
            }),
          }}
        />
      </head>
      <body suppressHydrationWarning>
        <MetaPixelScript pixelId={process.env.NEXT_PUBLIC_META_PIXEL_ID} />
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 3000,
            style: {
              background: "#1a1a2e",
              color: "#fff",
              borderRadius: "12px",
              padding: "12px 16px",
              fontSize: "14px",
            },
            success: {
              iconTheme: { primary: "#f97316", secondary: "#fff" },
            },
          }}
        />
      </body>
    </html>
  );
}
