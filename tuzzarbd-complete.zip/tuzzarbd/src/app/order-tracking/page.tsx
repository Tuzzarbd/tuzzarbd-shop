// src/app/order-tracking/page.tsx
"use client";

import { useState } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Search, Package, Truck, CheckCircle, Clock, XCircle, MapPin, Phone, ArrowRight, Loader2 } from "lucide-react";

interface TrackingResult {
  orderNumber: string;
  status: string;
  customer: string;
  phone: string;
  district: string;
  upazila: string;
  total: number;
  items: { name: string; qty: number; price: number }[];
  timeline: { status: string; time: string; note?: string }[];
  trackingNumber?: string;
  courierName?: string;
}

const STATUS_STEPS = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED"];

const STATUS_CONFIG: Record<string, { label: string; color: string; bgColor: string; icon: React.ElementType }> = {
  PENDING: { label: "অপেক্ষমান", color: "text-amber-600", bgColor: "bg-amber-100", icon: Clock },
  CONFIRMED: { label: "নিশ্চিত হয়েছে", color: "text-blue-600", bgColor: "bg-blue-100", icon: CheckCircle },
  PROCESSING: { label: "প্রস্তুত হচ্ছে", color: "text-purple-600", bgColor: "bg-purple-100", icon: Package },
  SHIPPED: { label: "পাঠানো হয়েছে", color: "text-indigo-600", bgColor: "bg-indigo-100", icon: Truck },
  DELIVERED: { label: "ডেলিভারি হয়েছে", color: "text-green-600", bgColor: "bg-green-100", icon: CheckCircle },
  CANCELLED: { label: "বাতিল", color: "text-red-600", bgColor: "bg-red-100", icon: XCircle },
};

// Demo data
const DEMO_RESULT: TrackingResult = {
  orderNumber: "TZ-DEMO-001",
  status: "SHIPPED",
  customer: "রহিম উদ্দিন",
  phone: "017XXXXXXXX",
  district: "Chittagong",
  upazila: "Hathazari",
  total: 2650,
  items: [
    { name: "প্রিমিয়াম কটন শার্ট - Navy Blue (L)", qty: 2, price: 850 },
    { name: "ভিটামিন C ফেসওয়াশ (100ml)", qty: 1, price: 350 },
  ],
  trackingNumber: "SA123456789BD",
  courierName: "Sundarban Courier",
  timeline: [
    { status: "PENDING", time: "১৫ মার্চ, ২০২৪ — সকাল ১০:৩০", note: "অর্ডার গ্রহণ করা হয়েছে" },
    { status: "CONFIRMED", time: "১৫ মার্চ, ২০২৪ — দুপুর ১২:০০", note: "অর্ডার নিশ্চিত হয়েছে" },
    { status: "PROCESSING", time: "১৫ মার্চ, ২০২৪ — বিকাল ৩:০০", note: "পণ্য প্যাক করা হচ্ছে" },
    { status: "SHIPPED", time: "১৬ মার্চ, ২০২৪ — সকাল ৯:০০", note: "Sundarban Courier এ হস্তান্তর করা হয়েছে" },
  ],
};

export default function OrderTrackingPage() {
  const [query, setQuery] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TrackingResult | null>(null);
  const [error, setError] = useState("");

  const handleTrack = async () => {
    if (!query.trim()) {
      setError("অর্ডার নম্বর দিন");
      return;
    }
    setLoading(true);
    setError("");
    setResult(null);

    await new Promise((r) => setTimeout(r, 1200));

    // Demo: return fake result for any input
    if (query.toUpperCase().includes("DEMO") || true) {
      setResult({ ...DEMO_RESULT, orderNumber: query.toUpperCase() });
    } else {
      setError("এই অর্ডার নম্বর দিয়ে কোনো অর্ডার পাওয়া যায়নি।");
    }
    setLoading(false);
  };

  const currentStepIndex = result ? STATUS_STEPS.indexOf(result.status) : -1;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-3xl mx-auto px-4 py-12">
        {/* Title */}
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-brand-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Package className="w-9 h-9 text-brand-600" />
          </div>
          <h1 className="text-3xl font-bold text-accent font-display mb-2">অর্ডার ট্র্যাক করুন</h1>
          <p className="text-gray-500 font-bangla">আপনার অর্ডার নম্বর দিয়ে ডেলিভারির অবস্থান জানুন</p>
        </div>

        {/* Search Box */}
        <div className="card p-6 mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="label font-bangla">অর্ডার নম্বর *</label>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="TZ-XXXXXX-XXXX"
                className="input font-mono text-sm"
                onKeyDown={(e) => e.key === "Enter" && handleTrack()}
              />
            </div>
            <div>
              <label className="label font-bangla">ফোন নম্বর (ঐচ্ছিক)</label>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="input font-mono text-sm"
              />
            </div>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm font-bangla flex items-center gap-2">
              <XCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          )}

          <button
            onClick={handleTrack}
            disabled={loading}
            className="btn-primary w-full flex items-center justify-center gap-2 font-bangla"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                খোঁজা হচ্ছে...
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                ট্র্যাক করুন
              </>
            )}
          </button>

          <p className="text-xs text-center text-gray-400 font-bangla mt-3">
            ডেমো দেখতে যেকোনো অর্ডার নম্বর দিন
          </p>
        </div>

        {/* Result */}
        {result && (
          <div className="space-y-5 animate-fade-in">
            {/* Status Header */}
            <div className="card p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-xs text-gray-500 font-bangla mb-1">অর্ডার নম্বর</p>
                  <p className="font-bold font-mono text-accent text-lg">{result.orderNumber}</p>
                </div>
                {(() => {
                  const cfg = STATUS_CONFIG[result.status];
                  const Icon = cfg.icon;
                  return (
                    <span className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-bold font-bangla ${cfg.bgColor} ${cfg.color}`}>
                      <Icon className="w-4 h-4" />
                      {cfg.label}
                    </span>
                  );
                })()}
              </div>

              {/* Progress Bar */}
              {result.status !== "CANCELLED" && (
                <div className="relative mt-6">
                  <div className="absolute top-4 left-0 right-0 h-1 bg-gray-200 rounded">
                    <div
                      className="h-full bg-brand-500 rounded transition-all duration-700"
                      style={{
                        width: `${((currentStepIndex) / (STATUS_STEPS.length - 1)) * 100}%`,
                      }}
                    />
                  </div>
                  <div className="relative flex justify-between">
                    {STATUS_STEPS.map((step, i) => {
                      const cfg = STATUS_CONFIG[step];
                      const done = i <= currentStepIndex;
                      const Icon = cfg.icon;
                      return (
                        <div key={step} className="flex flex-col items-center gap-2">
                          <div
                            className={`w-9 h-9 rounded-full flex items-center justify-center border-2 z-10 transition-all ${
                              done
                                ? "bg-brand-500 border-brand-500 text-white shadow-brand"
                                : "bg-white border-gray-200 text-gray-300"
                            }`}
                          >
                            <Icon className="w-4 h-4" />
                          </div>
                          <p className={`text-xs font-medium font-bangla text-center hidden sm:block ${done ? "text-brand-600" : "text-gray-400"}`}>
                            {cfg.label}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Courier Info */}
            {result.trackingNumber && (
              <div className="card p-5 bg-indigo-50 border border-indigo-100">
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="font-semibold text-indigo-900 text-sm font-bangla">কুরিয়ার তথ্য</p>
                    <p className="text-sm text-indigo-700">{result.courierName} — <span className="font-mono font-bold">{result.trackingNumber}</span></p>
                  </div>
                </div>
              </div>
            )}

            {/* Delivery Address */}
            <div className="card p-5">
              <h3 className="font-semibold text-accent mb-3 font-display flex items-center gap-2">
                <MapPin className="w-4 h-4 text-brand-500" />
                ডেলিভারির ঠিকানা
              </h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-gray-400 text-xs font-bangla">প্রাপক</p>
                  <p className="font-semibold font-bangla">{result.customer}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-xs font-bangla">ফোন</p>
                  <p className="font-semibold font-mono">{result.phone}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-gray-400 text-xs font-bangla">ঠিকানা</p>
                  <p className="font-semibold font-bangla">{result.upazila}, {result.district}</p>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="card p-5">
              <h3 className="font-semibold text-accent mb-3 font-display flex items-center gap-2">
                <Package className="w-4 h-4 text-brand-500" />
                অর্ডারকৃত পণ্য
              </h3>
              <div className="space-y-2">
                {result.items.map((item, i) => (
                  <div key={i} className="flex justify-between text-sm py-2 border-b border-gray-50 last:border-0">
                    <div>
                      <p className="font-medium font-bangla">{item.name}</p>
                      <p className="text-xs text-gray-400 font-bangla">পরিমাণ: {item.qty}টি</p>
                    </div>
                    <p className="font-bold text-accent">৳{(item.price * item.qty).toLocaleString()}</p>
                  </div>
                ))}
                <div className="flex justify-between pt-2 font-bold">
                  <span className="font-bangla">মোট</span>
                  <span className="text-brand-600">৳{result.total.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Timeline */}
            <div className="card p-5">
              <h3 className="font-semibold text-accent mb-4 font-display">অগ্রগতির ইতিহাস</h3>
              <div className="space-y-4">
                {result.timeline.map((entry, i) => {
                  const cfg = STATUS_CONFIG[entry.status];
                  const Icon = cfg.icon;
                  return (
                    <div key={i} className="flex gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${cfg.bgColor}`}>
                        <Icon className={`w-4 h-4 ${cfg.color}`} />
                      </div>
                      <div>
                        <p className={`text-sm font-semibold ${cfg.color} font-bangla`}>{cfg.label}</p>
                        <p className="text-xs text-gray-500 font-bangla">{entry.time}</p>
                        {entry.note && <p className="text-xs text-gray-600 font-bangla mt-1">{entry.note}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Help */}
            <div className="text-center py-4">
              <p className="text-sm text-gray-500 font-bangla mb-3">কোনো সমস্যা হচ্ছে?</p>
              <a
                href={`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}?text=আমার অর্ডার ${result.orderNumber} সম্পর্কে জানতে চাই`}
                className="btn-primary inline-flex items-center gap-2 text-sm font-bangla"
              >
                WhatsApp-এ যোগাযোগ করুন
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
