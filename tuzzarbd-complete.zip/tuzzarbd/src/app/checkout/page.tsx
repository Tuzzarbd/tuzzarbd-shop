// src/app/checkout/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { DISTRICTS, getShippingCharge, isDhakaDistrict, getUpazilasForDistrict } from "@/lib/bangladesh-geo";
import {
  ShoppingCart, MapPin, Phone, User, ChevronDown,
  CheckCircle, AlertCircle, Truck, Tag, Loader2,
  CreditCard, Smartphone, Banknote, Gift, ArrowRight
} from "lucide-react";
import toast from "react-hot-toast";

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  variant?: string;
}

const MOCK_CART: CartItem[] = [
  { id: "1", name: "প্রিমিয়াম কটন শার্ট - Navy Blue (L)", price: 850, quantity: 2, image: "👕" },
  { id: "2", name: "ভিটামিন C ফেসওয়াশ (100ml)", price: 350, quantity: 1, image: "🧴" },
];

const PAYMENT_METHODS = [
  { id: "COD", label: "ক্যাশ অন ডেলিভারি", icon: Banknote, desc: "পণ্য পাওয়ার পর পেমেন্ট করুন", color: "border-green-200 bg-green-50" },
  { id: "BKASH", label: "bKash", icon: Smartphone, desc: "বিকাশে পেমেন্ট করুন", color: "border-pink-200 bg-pink-50" },
  { id: "NAGAD", label: "Nagad", icon: Smartphone, desc: "নগদে পেমেন্ট করুন", color: "border-orange-200 bg-orange-50" },
  { id: "ROCKET", label: "Rocket", icon: Smartphone, desc: "রকেটে পেমেন্ট করুন", color: "border-purple-200 bg-purple-50" },
];

export default function CheckoutPage() {
  const router = useRouter();
  const [step, setStep] = useState<"info" | "confirm" | "success">("info");
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [otp, setOtp] = useState("");
  const [coupon, setCoupon] = useState("");
  const [couponApplied, setCouponApplied] = useState<{code: string; discount: number} | null>(null);
  const [phoneTimer, setPhoneTimer] = useState(0);

  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    district: "",
    upazila: "",
    area: "",
    address: "",
    note: "",
    paymentMethod: "COD",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const upazilas = form.district ? getUpazilasForDistrict(form.district) : [];
  const selectedDistrict = DISTRICTS.find((d) => d.id === form.district);
  const isDhaka = selectedDistrict?.isDhaka ?? false;
  const shippingCharge = selectedDistrict ? getShippingCharge(selectedDistrict.name) : 0;

  const subtotal = MOCK_CART.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = couponApplied?.discount ?? 0;
  const total = subtotal + shippingCharge - discount;

  // OTP Timer
  useEffect(() => {
    if (phoneTimer > 0) {
      const t = setTimeout(() => setPhoneTimer((p) => p - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [phoneTimer]);

  const updateForm = (key: string, val: string) => {
    setForm((prev) => ({ ...prev, [key]: val }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: "" }));
    if (key === "district") {
      setForm((prev) => ({ ...prev, district: val, upazila: "" }));
    }
  };

  const validatePhone = (phone: string) => /^01[3-9]\d{8}$/.test(phone);

  const sendOTP = async () => {
    if (!validatePhone(form.phone)) {
      toast.error("সঠিক ফোন নম্বর দিন (01XXXXXXXXX)");
      return;
    }
    setLoading(true);
    // Placeholder: real SMS OTP integration
    await new Promise((r) => setTimeout(r, 1500));
    setOtpSent(true);
    setPhoneTimer(60);
    toast.success(`${form.phone} নম্বরে OTP পাঠানো হয়েছে`);
    setLoading(false);
  };

  const verifyOTP = async () => {
    if (otp.length !== 6) {
      toast.error("৬ সংখ্যার OTP দিন");
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    // Demo: any 6-digit OTP works
    setOtpVerified(true);
    toast.success("ফোন নম্বর যাচাই সম্পন্ন!");
    setLoading(false);
  };

  const applyCoupon = async () => {
    if (!coupon.trim()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    // Demo coupon
    if (coupon.toUpperCase() === "TUZZAR10") {
      const disc = Math.round(subtotal * 0.1);
      setCouponApplied({ code: coupon.toUpperCase(), discount: disc });
      toast.success(`কুপন প্রয়োগ করা হয়েছে! ৳${disc} ছাড়`);
    } else {
      toast.error("অবৈধ কুপন কোড");
    }
    setLoading(false);
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!form.name.trim()) newErrors.name = "নাম দিন";
    if (!validatePhone(form.phone)) newErrors.phone = "সঠিক ফোন নম্বর দিন (01XXXXXXXXX)";
    if (!form.district) newErrors.district = "জেলা নির্বাচন করুন";
    if (!form.upazila) newErrors.upazila = "উপজেলা নির্বাচন করুন";
    if (!form.address.trim()) newErrors.address = "বিস্তারিত ঠিকানা দিন";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) {
      toast.error("সকল তথ্য সঠিকভাবে পূরণ করুন");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: MOCK_CART,
          subtotal,
          shippingCharge,
          discount,
          total,
          couponCode: couponApplied?.code,
          isDhaka,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setStep("success");
        // Meta Pixel Purchase event
        if (typeof window !== "undefined" && window.fbq) {
          window.fbq("track", "Purchase", {
            value: total,
            currency: "BDT",
            content_ids: MOCK_CART.map((i) => i.id),
            num_items: MOCK_CART.reduce((s, i) => s + i.quantity, 0),
            order_id: data.orderNumber,
          });
        }
      } else {
        toast.error(data.error || "অর্ডার দেওয়া যায়নি");
      }
    } catch {
      toast.error("নেটওয়ার্ক সমস্যা। পুনরায় চেষ্টা করুন।");
    } finally {
      setLoading(false);
    }
  };

  if (step === "success") {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-lg mx-auto px-4 py-20 text-center">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-14 h-14 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-accent font-display mb-2">অর্ডার সম্পন্ন!</h1>
          <p className="text-gray-500 font-bangla mb-6">
            আপনার অর্ডার সফলভাবে গ্রহণ করা হয়েছে। শীঘ্রই আপনার সাথে যোগাযোগ করা হবে।
          </p>
          <div className="card p-6 mb-6 text-left space-y-3">
            <div className="flex justify-between text-sm font-bangla">
              <span className="text-gray-500">নাম</span>
              <span className="font-semibold">{form.name}</span>
            </div>
            <div className="flex justify-between text-sm font-bangla">
              <span className="text-gray-500">ফোন</span>
              <span className="font-semibold">{form.phone}</span>
            </div>
            <div className="flex justify-between text-sm font-bangla">
              <span className="text-gray-500">মোট</span>
              <span className="font-bold text-brand-600 text-lg">৳{total.toLocaleString()}</span>
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <a href="/order-tracking" className="btn-primary font-bangla">
              অর্ডার ট্র্যাক করুন
            </a>
            <a href="/" className="btn-secondary font-bangla">
              শপিং চালিয়ে যান
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-accent font-display mb-8 flex items-center gap-2">
          <ShoppingCart className="w-6 h-6 text-brand-500" />
          চেকআউট
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left: Form */}
          <div className="lg:col-span-3 space-y-6">
            {/* Customer Info */}
            <div className="card p-6">
              <h2 className="font-semibold text-accent mb-4 flex items-center gap-2 font-display">
                <User className="w-5 h-5 text-brand-500" />
                আপনার তথ্য
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="label font-bangla">পূর্ণ নাম *</label>
                  <input
                    value={form.name}
                    onChange={(e) => updateForm("name", e.target.value)}
                    placeholder="আপনার নাম লিখুন"
                    className={`input font-bangla ${errors.name ? "border-red-400 ring-red-200" : ""}`}
                  />
                  {errors.name && <p className="text-red-500 text-xs mt-1 font-bangla">{errors.name}</p>}
                </div>
                <div>
                  <label className="label font-bangla">ইমেইল (ঐচ্ছিক)</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => updateForm("email", e.target.value)}
                    placeholder="email@example.com"
                    className="input"
                  />
                </div>
              </div>

              {/* Phone + OTP */}
              <div className="mt-4">
                <label className="label font-bangla">মোবাইল নম্বর * (11 সংখ্যা)</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      value={form.phone}
                      onChange={(e) => updateForm("phone", e.target.value.replace(/\D/g, "").slice(0, 11))}
                      placeholder="01XXXXXXXXX"
                      className={`input pl-9 font-mono ${errors.phone ? "border-red-400" : otpVerified ? "border-green-400" : ""}`}
                      maxLength={11}
                    />
                    {otpVerified && (
                      <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500" />
                    )}
                  </div>
                  {!otpVerified && (
                    <button
                      onClick={sendOTP}
                      disabled={loading || phoneTimer > 0 || form.phone.length !== 11}
                      className="btn-secondary text-sm py-2.5 px-4 whitespace-nowrap font-bangla disabled:opacity-50"
                    >
                      {phoneTimer > 0 ? `${phoneTimer}s` : otpSent ? "রিসেন্ড" : "OTP পাঠান"}
                    </button>
                  )}
                </div>
                {errors.phone && <p className="text-red-500 text-xs mt-1 font-bangla">{errors.phone}</p>}

                {/* OTP Input */}
                {otpSent && !otpVerified && (
                  <div className="mt-3 flex gap-2">
                    <input
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                      placeholder="6 সংখ্যার OTP"
                      className="input flex-1 font-mono text-center tracking-widest text-lg"
                      maxLength={6}
                    />
                    <button
                      onClick={verifyOTP}
                      disabled={loading || otp.length !== 6}
                      className="btn-primary text-sm px-4 font-bangla disabled:opacity-50"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "যাচাই করুন"}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Shipping Address */}
            <div className="card p-6">
              <h2 className="font-semibold text-accent mb-4 flex items-center gap-2 font-display">
                <MapPin className="w-5 h-5 text-brand-500" />
                ডেলিভারি ঠিকানা
              </h2>

              {/* District + Upazila Cascading Dropdowns */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="label font-bangla">জেলা *</label>
                  <div className="relative">
                    <select
                      value={form.district}
                      onChange={(e) => updateForm("district", e.target.value)}
                      className={`input appearance-none pr-8 font-bangla ${errors.district ? "border-red-400" : ""}`}
                    >
                      <option value="">জেলা নির্বাচন করুন</option>
                      {DISTRICTS.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name} {d.isDhaka ? "🟢" : ""}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>
                  {errors.district && <p className="text-red-500 text-xs mt-1 font-bangla">{errors.district}</p>}

                  {/* Shipping Badge */}
                  {form.district && (
                    <div className={`mt-2 flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded-lg ${isDhaka ? "bg-green-50 text-green-700" : "bg-orange-50 text-orange-700"}`}>
                      <Truck className="w-3 h-3" />
                      <span className="font-bangla">
                        {isDhaka ? "ঢাকার ভেতরে — শিপিং ৳৮০" : "ঢাকার বাইরে — শিপিং ৳১৫০"}
                      </span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="label font-bangla">উপজেলা / থানা *</label>
                  <div className="relative">
                    <select
                      value={form.upazila}
                      onChange={(e) => updateForm("upazila", e.target.value)}
                      disabled={!form.district}
                      className={`input appearance-none pr-8 font-bangla ${errors.upazila ? "border-red-400" : ""} disabled:bg-gray-50 disabled:text-gray-400`}
                    >
                      <option value="">উপজেলা নির্বাচন করুন</option>
                      {upazilas.map((u) => (
                        <option key={u.id} value={u.id}>{u.name}</option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>
                  {errors.upazila && <p className="text-red-500 text-xs mt-1 font-bangla">{errors.upazila}</p>}
                </div>
              </div>

              <div className="mb-4">
                <label className="label font-bangla">এলাকা / রোড (ঐচ্ছিক)</label>
                <input
                  value={form.area}
                  onChange={(e) => updateForm("area", e.target.value)}
                  placeholder="এলাকার নাম, রোড নম্বর..."
                  className="input font-bangla"
                />
              </div>

              <div className="mb-4">
                <label className="label font-bangla">বিস্তারিত ঠিকানা *</label>
                <textarea
                  value={form.address}
                  onChange={(e) => updateForm("address", e.target.value)}
                  placeholder="বাড়ি নম্বর, ফ্লাট, ল্যান্ডমার্ক..."
                  rows={3}
                  className={`input resize-none font-bangla ${errors.address ? "border-red-400" : ""}`}
                />
                {errors.address && <p className="text-red-500 text-xs mt-1 font-bangla">{errors.address}</p>}
              </div>

              <div>
                <label className="label font-bangla">বিশেষ নির্দেশনা (ঐচ্ছিক)</label>
                <input
                  value={form.note}
                  onChange={(e) => updateForm("note", e.target.value)}
                  placeholder="ডেলিভারির জন্য কোনো বিশেষ নির্দেশনা..."
                  className="input font-bangla"
                />
              </div>
            </div>

            {/* Payment Method */}
            <div className="card p-6">
              <h2 className="font-semibold text-accent mb-4 flex items-center gap-2 font-display">
                <CreditCard className="w-5 h-5 text-brand-500" />
                পেমেন্ট পদ্ধতি
              </h2>
              <div className="grid grid-cols-2 gap-3">
                {PAYMENT_METHODS.map((method) => (
                  <button
                    key={method.id}
                    onClick={() => updateForm("paymentMethod", method.id)}
                    className={`flex items-start gap-3 p-4 rounded-xl border-2 text-left transition-all ${
                      form.paymentMethod === method.id
                        ? "border-brand-400 bg-brand-50 shadow-sm"
                        : `border-gray-100 hover:border-gray-200 ${method.color}`
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${form.paymentMethod === method.id ? "border-brand-500 bg-brand-500" : "border-gray-300"}`}>
                      {form.paymentMethod === method.id && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-accent">{method.label}</p>
                      <p className="text-xs text-gray-500 font-bangla mt-0.5">{method.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Order Summary */}
          <div className="lg:col-span-2 space-y-4">
            {/* Cart Items */}
            <div className="card p-5">
              <h2 className="font-semibold text-accent mb-4 font-display flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-brand-500" />
                আপনার অর্ডার ({MOCK_CART.length}টি পণ্য)
              </h2>
              <div className="space-y-3">
                {MOCK_CART.map((item) => (
                  <div key={item.id} className="flex gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center text-2xl flex-shrink-0 shadow-sm">
                      {item.image}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 font-bangla leading-snug truncate">{item.name}</p>
                      <p className="text-xs text-gray-400 font-bangla mt-0.5">পরিমাণ: {item.quantity}টি</p>
                    </div>
                    <div className="text-sm font-bold text-accent whitespace-nowrap">
                      ৳{(item.price * item.quantity).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Coupon */}
            <div className="card p-5">
              <label className="label font-bangla flex items-center gap-1.5">
                <Gift className="w-4 h-4 text-brand-500" />
                কুপন কোড
              </label>
              <div className="flex gap-2">
                <input
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value.toUpperCase())}
                  placeholder="TUZZAR10"
                  disabled={!!couponApplied}
                  className="input flex-1 uppercase font-mono text-sm"
                />
                <button
                  onClick={applyCoupon}
                  disabled={loading || !!couponApplied || !coupon.trim()}
                  className="btn-secondary text-sm py-2.5 px-4 font-bangla disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "প্রয়োগ"}
                </button>
              </div>
              {couponApplied && (
                <p className="text-green-600 text-xs mt-2 flex items-center gap-1 font-bangla">
                  <CheckCircle className="w-3 h-3" />
                  কুপন "{couponApplied.code}" — ৳{couponApplied.discount} ছাড়!
                </p>
              )}
            </div>

            {/* Price Summary */}
            <div className="card p-5 space-y-3">
              <div className="flex justify-between text-sm font-bangla">
                <span className="text-gray-600">সাবটোটাল</span>
                <span className="font-semibold">৳{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm font-bangla">
                <span className="text-gray-600 flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5" />
                  শিপিং চার্জ
                </span>
                <span className={`font-semibold ${!form.district ? "text-gray-400" : isDhaka ? "text-green-600" : "text-orange-600"}`}>
                  {!form.district ? "জেলা নির্বাচন করুন" : `৳${shippingCharge}`}
                </span>
              </div>
              {couponApplied && (
                <div className="flex justify-between text-sm font-bangla">
                  <span className="text-green-600">কুপন ছাড়</span>
                  <span className="font-semibold text-green-600">-৳{discount.toLocaleString()}</span>
                </div>
              )}
              <div className="border-t border-gray-100 pt-3 flex justify-between font-bangla">
                <span className="font-bold text-accent text-base">মোট পরিমাণ</span>
                <span className="font-bold text-brand-600 text-xl">৳{total.toLocaleString()}</span>
              </div>
            </div>

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="btn-primary w-full flex items-center justify-center gap-3 text-base py-4 font-bangla disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  অর্ডার প্রক্রিয়াধীন...
                </>
              ) : (
                <>
                  অর্ডার নিশ্চিত করুন
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>

            <p className="text-xs text-center text-gray-400 font-bangla">
              🔒 আপনার তথ্য সম্পূর্ণ নিরাপদ। অর্ডার দিলে আমাদের{" "}
              <a href="/terms" className="underline">শর্তাবলী</a> মেনে নেওয়া হবে।
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
