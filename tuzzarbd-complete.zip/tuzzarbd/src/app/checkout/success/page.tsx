// src/app/checkout/success/page.tsx
"use client";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import Link from "next/link";
import { CheckCircle, Package, MessageCircle, Home } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

function SuccessContent() {
  const params = useSearchParams();
  const orderNumber = params.get("order") || "";
  const payment = params.get("payment") || "cod";

  const paymentLabels: Record<string, string> = {
    bkash: "bKash", nagad: "Nagad", rocket: "Rocket", cod: "ক্যাশ অন ডেলিভারি",
  };

  const waLink = `https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}?text=আমার অর্ডার ${orderNumber} নিশ্চিত হয়েছে। ধন্যবাদ!`;

  return (
    <div className="max-w-lg mx-auto px-4 py-16 text-center">
      <div className="w-28 h-28 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce-in">
        <CheckCircle className="w-16 h-16 text-green-500" />
      </div>

      <h1 className="text-3xl font-bold text-accent font-display mb-3">
        অর্ডার সফল! 🎉
      </h1>

      <div className="card p-6 mb-6 text-left space-y-3">
        <div className="flex justify-between text-sm font-bangla border-b border-gray-100 pb-3">
          <span className="text-gray-500">অর্ডার নম্বর</span>
          <span className="font-bold font-mono text-brand-600">#{orderNumber}</span>
        </div>
        <div className="flex justify-between text-sm font-bangla">
          <span className="text-gray-500">পেমেন্ট পদ্ধতি</span>
          <span className="font-semibold">{paymentLabels[payment] || payment}</span>
        </div>
        <div className="flex justify-between text-sm font-bangla">
          <span className="text-gray-500">ডেলিভারি সময়</span>
          <span className="font-semibold text-green-600">১-৪ কার্যদিবস</span>
        </div>
      </div>

      <p className="text-gray-500 font-bangla text-sm mb-6">
        আপনার অর্ডারের আপডেট SMS ও WhatsApp-এ পাঠানো হবে।
      </p>

      <div className="grid grid-cols-1 gap-3">
        <Link href={`/order-tracking?order=${orderNumber}`} className="btn-primary flex items-center justify-center gap-2 font-bangla">
          <Package className="w-5 h-5" />
          অর্ডার ট্র্যাক করুন
        </Link>
        <a href={waLink} target="_blank" rel="noopener noreferrer"
          className="btn-secondary flex items-center justify-center gap-2 font-bangla"
          style={{ borderColor: "#25D366", color: "#25D366" }}>
          <MessageCircle className="w-5 h-5" />
          WhatsApp-এ যোগাযোগ
        </a>
        <Link href="/" className="flex items-center justify-center gap-2 text-sm text-gray-500 hover:text-accent font-bangla py-2">
          <Home className="w-4 h-4" />
          হোমপেজে ফিরে যান
        </Link>
      </div>
    </div>
  );
}

export default function CheckoutSuccessPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Suspense fallback={<div className="text-center py-20 font-bangla">লোড হচ্ছে...</div>}>
        <SuccessContent />
      </Suspense>
      <Footer />
    </div>
  );
}
