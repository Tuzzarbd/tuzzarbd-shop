// src/app/page.tsx
import { Suspense } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/shop/HeroSection";
import CategoryGrid from "@/components/shop/CategoryGrid";
import FeaturedProducts from "@/components/shop/FeaturedProducts";
import TrustBadges from "@/components/shop/TrustBadges";
import WhatsAppButton from "@/components/ui/WhatsAppButton";
import RecentSalesPopup from "@/components/shop/RecentSalesPopup";
import MetaPixelInit from "@/components/ui/MetaPixelInit";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "tuzzarbd — ফ্যাশন, গ্যাজেট ও বিউটি | বাংলাদেশের সেরা অনলাইন শপ",
  description: "তুজারবিডি — বাংলাদেশের প্রিমিয়াম অনলাইন শপ। ফ্যাশন, স্মার্ট গ্যাজেট ও বিউটি কেয়ার পণ্য। ঢাকায় ৳৮০ এবং সারা বাংলাদেশে ৳১৫০ শিপিং।",
};

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <MetaPixelInit event="PageView" />
      <Header />
      
      <main>
        <HeroSection />
        <TrustBadges />
        <CategoryGrid />
        <Suspense fallback={<div className="h-96 bg-gray-50 animate-pulse" />}>
          <FeaturedProducts />
        </Suspense>
        
        {/* Banner Section */}
        <section className="py-16 bg-gradient-to-r from-accent to-accent-light">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
              সারা বাংলাদেশে দ্রুত ডেলিভারি
            </h2>
            <p className="text-lg text-white/80 font-bangla mb-8">
              ঢাকার ভেতরে মাত্র ৳৮০ • ঢাকার বাইরে ৳১৫০
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a href="/shop" className="btn-primary font-bangla">
                এখনই কেনাকাটা করুন
              </a>
              <a
                href="https://wa.me/8801XXXXXXXXX"
                className="btn-secondary bg-transparent border-white text-white hover:bg-white hover:text-accent font-bangla"
              >
                WhatsApp-এ অর্ডার করুন
              </a>
            </div>
          </div>
        </section>

        {/* New Arrivals */}
        <Suspense fallback={<div className="h-96 bg-white animate-pulse" />}>
          <FeaturedProducts title="নতুন পণ্য" subtitle="সদ্য আসা পণ্যসমূহ" type="new" />
        </Suspense>

        {/* Testimonials */}
        <section className="py-16 bg-brand-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="section-title font-bangla">আমাদের কাস্টমারদের মতামত</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  name: "সুমাইয়া বেগম",
                  location: "ঢাকা",
                  review: "অসাধারণ পণ্যের মান! খুব দ্রুত ডেলিভারি পেলাম। পরের বার আবার অর্ডার করব।",
                  rating: 5,
                  product: "ভিটামিন C ফেসওয়াশ",
                },
                {
                  name: "রফিকুল ইসলাম",
                  location: "চট্টগ্রাম",
                  review: "Samsung earbuds এর দাম অনেক ভালো পেলাম। প্যাকেজিং দারুণ ছিল।",
                  rating: 5,
                  product: "Samsung Galaxy Buds",
                },
                {
                  name: "ফারজানা আক্তার",
                  location: "সিলেট",
                  review: "শাড়ির কোয়ালিটি ফটোর মতোই। অনেক খুশি। সবাইকে রেকমেন্ড করব।",
                  rating: 4,
                  product: "সিল্ক শাড়ি",
                },
              ].map((review, i) => (
                <div key={i} className="card p-6">
                  <div className="flex gap-1 mb-3">
                    {Array.from({ length: review.rating }).map((_, j) => (
                      <span key={j} className="text-amber-400 text-lg">★</span>
                    ))}
                  </div>
                  <p className="text-gray-700 font-bangla text-sm leading-relaxed mb-4">
                    "{review.review}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-brand-100 rounded-full flex items-center justify-center text-brand-700 font-bold">
                      {review.name[0]}
                    </div>
                    <div>
                      <p className="font-semibold text-accent font-bangla text-sm">{review.name}</p>
                      <p className="text-xs text-gray-400 font-bangla">{review.location} • {review.product}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppButton />
      <RecentSalesPopup />
    </div>
  );
}
