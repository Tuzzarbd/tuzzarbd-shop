// src/app/api/admin/auth/login/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { verifyPassword, signToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: "ইমেইল ও পাসওয়ার্ড দিন" }, { status: 400 });
    }

    // Find admin user
    const user = await prisma.user.findFirst({
      where: { email: email.toLowerCase(), role: { in: ["ADMIN", "MANAGER"] }, isActive: true },
    });

    // Demo mode: accept hardcoded credentials if no DB
    const isDemoMode = !user;
    const demoEmail = process.env.ADMIN_EMAIL || "admin@tuzzarbd.com";
    const demoPass = process.env.ADMIN_PASSWORD || "admin123";

    let authenticated = false;
    let adminData = { id: "demo", email: demoEmail, role: "ADMIN", name: "Admin" };

    if (isDemoMode) {
      authenticated = email === demoEmail && password === demoPass;
    } else {
      authenticated = await verifyPassword(password, user!.passwordHash || "");
      adminData = { id: user!.id, email: user!.email, role: user!.role, name: user!.name };
    }

    if (!authenticated) {
      return NextResponse.json({ error: "ইমেইল বা পাসওয়ার্ড ভুল" }, { status: 401 });
    }

    const token = await signToken(adminData);

    const response = NextResponse.json({ success: true, admin: adminData });
    response.cookies.set("admin_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60,
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json({ error: "সার্ভার ত্রুটি" }, { status: 500 });
  }
}
