// src/app/api/payments/nagad/initialize/route.ts
import { NextRequest, NextResponse } from "next/server";
import { initNagadPayment } from "@/lib/nagad";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { orderId } = await req.json();
    if (!orderId) return NextResponse.json({ error: "orderId দিন" }, { status: 400 });

    const order = await prisma.order.findUnique({ where: { id: orderId } });
    if (!order) return NextResponse.json({ error: "অর্ডার পাওয়া যায়নি" }, { status: 404 });
    if (order.paymentStatus === "PAID") return NextResponse.json({ error: "ইতিমধ্যে পেমেন্ট হয়েছে" }, { status: 400 });

    const result = await initNagadPayment({
      orderId: order.orderNumber,
      amount: Number(order.total),
    });

    return NextResponse.json(result);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "নগদ পেমেন্ট শুরু করা যায়নি";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
