// src/app/api/payments/nagad/callback/route.ts
import { NextRequest, NextResponse } from "next/server";
import { verifyNagadPayment } from "@/lib/nagad";
import { prisma } from "@/lib/db";
import { sendCAPIEvent, hashData } from "@/lib/tracking";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const orderNumber = searchParams.get("order_id");
  const paymentRefId = searchParams.get("payment_ref_id");
  const status = searchParams.get("status");
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

  if (status !== "Success" || !paymentRefId || !orderNumber) {
    return NextResponse.redirect(`${siteUrl}/checkout?payment=failed&gateway=nagad`);
  }

  try {
    // Verify with Nagad
    const verification = await verifyNagadPayment(paymentRefId);
    if (verification.status !== "Success") {
      return NextResponse.redirect(`${siteUrl}/checkout?payment=failed&gateway=nagad`);
    }

    const order = await prisma.order.findUnique({
      where: { orderNumber: orderNumber.toUpperCase() },
      include: { items: true },
    });

    if (!order) return NextResponse.redirect(`${siteUrl}/checkout?payment=error`);

    await prisma.order.update({
      where: { id: order.id },
      data: {
        paymentStatus: "PAID",
        status: "CONFIRMED",
        paymentMethod: "NAGAD",
        statusHistory: {
          create: {
            status: "CONFIRMED",
            note: `নগদ পেমেন্ট সম্পন্ন। Ref: ${paymentRefId}`,
          },
        },
      },
    });

    // Meta CAPI
    await sendCAPIEvent({
      event_name: "Purchase",
      event_time: Math.floor(Date.now() / 1000),
      action_source: "website",
      user_data: {
        ph: order.guestPhone ? [await hashData(order.guestPhone)] : [],
      },
      custom_data: {
        value: Number(order.total),
        currency: "BDT",
        order_id: order.orderNumber,
        payment_method: "nagad",
      },
      event_id: `purchase_${order.orderNumber}`,
    });

    return NextResponse.redirect(
      `${siteUrl}/checkout/success?order=${order.orderNumber}&payment=nagad`
    );
  } catch (error) {
    console.error("Nagad callback error:", error);
    return NextResponse.redirect(`${siteUrl}/checkout?payment=error`);
  }
}
