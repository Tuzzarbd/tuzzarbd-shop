// src/app/api/payments/bkash/callback/route.ts
import { NextRequest, NextResponse } from "next/server";
import { executeBkashPayment } from "@/lib/bkash";
import { prisma } from "@/lib/db";
import { sendCAPIEvent, hashData } from "@/lib/tracking";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const paymentID = searchParams.get("paymentID");
  const status = searchParams.get("status");
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

  // Payment cancelled or failed
  if (status === "cancel") {
    return NextResponse.redirect(`${siteUrl}/checkout?payment=cancelled`);
  }
  if (status === "failure") {
    return NextResponse.redirect(`${siteUrl}/checkout?payment=failed`);
  }

  if (!paymentID) {
    return NextResponse.redirect(`${siteUrl}/checkout?payment=error`);
  }

  try {
    // Execute the payment
    const result = await executeBkashPayment(paymentID);

    if (result.transactionStatus !== "Completed") {
      console.error("bKash execute failed:", result);
      return NextResponse.redirect(`${siteUrl}/checkout?payment=failed`);
    }

    // Find order by merchantInvoiceNumber (= orderNumber)
    const order = await prisma.order.findUnique({
      where: { orderNumber: result.merchantInvoiceNumber },
      include: { items: true },
    });

    if (!order) {
      console.error("bKash: Order not found for", result.merchantInvoiceNumber);
      return NextResponse.redirect(`${siteUrl}/checkout?payment=error`);
    }

    // Update order payment status
    await prisma.order.update({
      where: { id: order.id },
      data: {
        paymentStatus: "PAID",
        status: "CONFIRMED",
        paymentMethod: "BKASH",
        statusHistory: {
          create: {
            status: "CONFIRMED",
            note: `bKash পেমেন্ট সম্পন্ন। TrxID: ${result.trxID}`,
          },
        },
      },
    });

    // Meta CAPI Purchase event (server-side)
    await sendCAPIEvent({
      event_name: "Purchase",
      event_time: Math.floor(Date.now() / 1000),
      action_source: "website",
      user_data: {
        ph: order.guestPhone ? [await hashData(order.guestPhone)] : [],
      },
      custom_data: {
        value: Number(order.total),
        currency: "BDT",
        content_ids: order.items.map((i) => i.productId),
        order_id: order.orderNumber,
        payment_method: "bkash",
      },
      event_id: `purchase_${order.orderNumber}`,
    });

    // Redirect to success page
    return NextResponse.redirect(
      `${siteUrl}/checkout/success?order=${order.orderNumber}&payment=bkash`
    );
  } catch (error) {
    console.error("bKash callback error:", error);
    return NextResponse.redirect(`${siteUrl}/checkout?payment=error`);
  }
}
