// src/app/api/payments/bkash/create/route.ts
import { NextRequest, NextResponse } from "next/server";
import { createBkashPayment } from "@/lib/bkash";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { orderId, amount } = await req.json();
    if (!orderId || !amount) {
      return NextResponse.json({ error: "orderId এবং amount দিন" }, { status: 400 });
    }

    // Verify order exists
    const order = await prisma.order.findUnique({ where: { id: orderId } });
    if (!order) return NextResponse.json({ error: "অর্ডার পাওয়া যায়নি" }, { status: 404 });
    if (order.paymentStatus === "PAID") return NextResponse.json({ error: "ইতিমধ্যে পেমেন্ট হয়েছে" }, { status: 400 });

    const payment = await createBkashPayment({
      amount: Number(order.total),
      orderId: order.orderNumber,
    });

    return NextResponse.json({ bkashURL: payment.bkashURL, paymentID: payment.paymentID });
  } catch (error: unknown) {
    console.error("bKash create error:", error);
    const message = error instanceof Error ? error.message : "বিকাশ পেমেন্ট শুরু করা যায়নি";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
