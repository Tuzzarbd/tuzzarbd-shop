// src/app/api/feed/route.ts
// Dynamic XML/JSON feed for Facebook & Google Ads
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://tuzzarbd.com";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const format = searchParams.get("format") || "xml"; // xml or json

  try {
    const products = await prisma.product.findMany({
      where: { isActive: true, stock: { gt: 0 } },
      include: {
        images: { where: { isMain: true }, take: 1 },
        category: true,
      },
      take: 1000,
    });

    if (format === "json") {
      // Google Merchant Center JSON format
      const feed = {
        version: "2.0",
        title: "tuzzarbd Product Feed",
        link: SITE_URL,
        updated: new Date().toISOString(),
        entries: products.map((p) => ({
          id: p.id,
          title: p.name,
          description: p.shortDesc || p.description || p.name,
          link: `${SITE_URL}/product/${p.slug}`,
          image_link: p.images[0]?.url || `${SITE_URL}/placeholder.jpg`,
          availability: p.stock > 0 ? "in stock" : "out of stock",
          price: `${p.price} BDT`,
          sale_price: p.comparePrice ? `${p.price} BDT` : undefined,
          brand: "tuzzarbd",
          condition: "new",
          google_product_category: getCategoryId(p.category.type),
          custom_label_0: p.category.type,
        })),
      };

      return NextResponse.json(feed, {
        headers: { "Cache-Control": "public, max-age=3600" },
      });
    }

    // Facebook Product Catalog XML (RSS 2.0)
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
  <channel>
    <title>tuzzarbd Product Catalog</title>
    <link>${SITE_URL}</link>
    <description>tuzzarbd — Fashion, Gadgets & Beauty Care</description>
    ${products.map((p) => `
    <item>
      <g:id>${p.id}</g:id>
      <g:title><![CDATA[${p.name}]]></g:title>
      <g:description><![CDATA[${(p.shortDesc || p.description || p.name).substring(0, 500)}]]></g:description>
      <g:link>${SITE_URL}/product/${p.slug}</g:link>
      <g:image_link>${p.images[0]?.url || `${SITE_URL}/placeholder.jpg`}</g:image_link>
      <g:availability>${p.stock > 0 ? "in stock" : "out of stock"}</g:availability>
      <g:price>${p.price} BDT</g:price>
      ${p.comparePrice ? `<g:sale_price>${p.price} BDT</g:sale_price>` : ""}
      <g:brand>tuzzarbd</g:brand>
      <g:condition>new</g:condition>
      <g:google_product_category>${getCategoryId(p.category.type)}</g:google_product_category>
      <g:custom_label_0>${p.category.type}</g:custom_label_0>
    </item>`).join("")}
  </channel>
</rss>`;

    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (error) {
    return NextResponse.json({ error: "Feed generation failed" }, { status: 500 });
  }
}

function getCategoryId(type: string): string {
  const map: Record<string, string> = {
    FASHION: "Apparel & Accessories",
    GADGETS: "Electronics",
    BEAUTY: "Health & Beauty",
  };
  return map[type] || "All";
}
