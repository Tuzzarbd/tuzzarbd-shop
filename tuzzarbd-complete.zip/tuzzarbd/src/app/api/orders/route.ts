// src/app/api/orders/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { generateOrderNumber, validateBDPhone } from "@/lib/db";
import { rateLimit } from "@/lib/auth";
import { getShippingCharge, isDhakaDistrict } from "@/lib/bangladesh-geo";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") || "unknown";

  // Rate limiting: max 10 orders per IP per minute
  if (!rateLimit(`order:${ip}`, 10, 60000)) {
    return NextResponse.json({ error: "অনেক বেশি অনুরোধ। একটু পর চেষ্টা করুন।" }, { status: 429 });
  }

  try {
    const body = await req.json();
    const { name, phone, email, district, upazila, area, address, note, paymentMethod, items, couponCode } = body;

    // Validation
    if (!name?.trim()) return NextResponse.json({ error: "নাম দিন" }, { status: 400 });
    if (!validateBDPhone(phone)) return NextResponse.json({ error: "সঠিক ফোন নম্বর দিন" }, { status: 400 });
    if (!district) return NextResponse.json({ error: "জেলা নির্বাচন করুন" }, { status: 400 });
    if (!upazila) return NextResponse.json({ error: "উপজেলা নির্বাচন করুন" }, { status: 400 });
    if (!address?.trim()) return NextResponse.json({ error: "ঠিকানা দিন" }, { status: 400 });
    if (!items?.length) return NextResponse.json({ error: "কার্ট খালি" }, { status: 400 });

    // Resolve district name
    const { DISTRICTS } = await import("@/lib/bangladesh-geo");
    const districtObj = DISTRICTS.find((d) => d.id === district || d.name === district);
    if (!districtObj) return NextResponse.json({ error: "অবৈধ জেলা" }, { status: 400 });

    const isDhaka = districtObj.isDhaka;
    const shippingCharge = isDhaka ? 80 : 150;

    // Calculate totals
    const subtotal = items.reduce((sum: number, item: { price: number; quantity: number }) => 
      sum + item.price * item.quantity, 0);

    // Validate coupon
    let couponDiscount = 0;
    let couponRecord = null;
    if (couponCode) {
      couponRecord = await prisma.coupon.findFirst({
        where: {
          code: couponCode.toUpperCase(),
          isActive: true,
          OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }],
          OR: [{ usageLimit: null }, { usageCount: { lt: prisma.coupon.fields.usageLimit } }],
        },
      }).catch(() => null);

      if (couponRecord) {
        if (couponRecord.discountType === "PERCENTAGE") {
          couponDiscount = Math.round((subtotal * Number(couponRecord.discountValue)) / 100);
          if (couponRecord.maxDiscount) {
            couponDiscount = Math.min(couponDiscount, Number(couponRecord.maxDiscount));
          }
        } else {
          couponDiscount = Number(couponRecord.discountValue);
        }
      }
    }

    const total = subtotal + shippingCharge - couponDiscount;
    const orderNumber = generateOrderNumber();

    // Resolve upazila name
    const upazilaObj = districtObj.upazilas.find((u) => u.id === upazila || u.name === upazila);

    // Create order
    const order = await prisma.order.create({
      data: {
        orderNumber,
        guestName: name.trim(),
        guestPhone: phone,
        guestEmail: email || null,
        status: "PENDING",
        paymentStatus: "UNPAID",
        paymentMethod: paymentMethod || "COD",
        subtotal,
        shippingCharge,
        discount: couponDiscount,
        total,
        couponCode: couponRecord ? couponCode.toUpperCase() : null,
        couponDiscount: couponDiscount > 0 ? couponDiscount : null,
        shippingName: name.trim(),
        shippingPhone: phone,
        shippingDistrict: districtObj.name,
        shippingUpazila: upazilaObj?.name || upazila,
        shippingArea: area || null,
        shippingAddress: address.trim(),
        shippingNote: note || null,
        isDhaka,
        ipAddress: ip,
        userAgent: req.headers.get("user-agent") || null,
        items: {
          create: items.map((item: { id: string; name: string; price: number; quantity: number; image?: string }) => ({
            productId: item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity,
            total: item.price * item.quantity,
            image: item.image || null,
          })),
        },
        statusHistory: {
          create: {
            status: "PENDING",
            note: "অর্ডার গ্রহণ করা হয়েছে",
          },
        },
      },
    });

    // Update coupon usage
    if (couponRecord) {
      await prisma.coupon.update({
        where: { id: couponRecord.id },
        data: { usageCount: { increment: 1 } },
      }).catch(() => {});
    }

    // Update stock (decrement)
    for (const item of items) {
      await prisma.product.update({
        where: { id: item.id },
        data: {
          stock: { decrement: item.quantity },
          totalSold: { increment: item.quantity },
        },
      }).catch(() => {});

      // Check low stock
      const product = await prisma.product.findUnique({ where: { id: item.id } }).catch(() => null);
      if (product && product.stock <= product.lowStockAlert) {
        await prisma.stockLog.create({
          data: {
            productId: item.id,
            type: product.stock === 0 ? "OUT_OF_STOCK" : "LOW_STOCK",
            prevStock: product.stock + item.quantity,
            newStock: product.stock,
            change: -item.quantity,
            note: `অর্ডার #${orderNumber} এর কারণে`,
          },
        }).catch(() => {});
      }
    }

    // Loyalty points (1 BDT = 1 point)
    // Future: if user is logged in, add points

    return NextResponse.json({
      success: true,
      orderNumber: order.orderNumber,
      orderId: order.id,
      total: order.total,
    }, { status: 201 });

  } catch (error) {
    console.error("Order creation error:", error);
    return NextResponse.json({ error: "অর্ডার সম্পন্ন হয়নি। পুনরায় চেষ্টা করুন।" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  // Public: track order by order number
  const { searchParams } = new URL(req.url);
  const orderNumber = searchParams.get("orderNumber");

  if (!orderNumber) {
    return NextResponse.json({ error: "অর্ডার নম্বর দিন" }, { status: 400 });
  }

  try {
    const order = await prisma.order.findUnique({
      where: { orderNumber: orderNumber.toUpperCase() },
      include: {
        items: { select: { name: true, quantity: true, price: true, total: true, image: true } },
        statusHistory: { orderBy: { createdAt: "asc" } },
      },
    });

    if (!order) {
      return NextResponse.json({ error: "অর্ডার পাওয়া যায়নি" }, { status: 404 });
    }

    // Return sanitized data (no sensitive admin info)
    return NextResponse.json({
      orderNumber: order.orderNumber,
      status: order.status,
      customer: order.shippingName,
      phone: order.shippingPhone?.replace(/(\d{3})\d{5}(\d{3})/, "$1XXXXX$2"),
      district: order.shippingDistrict,
      upazila: order.shippingUpazila,
      total: order.total,
      trackingNumber: order.trackingNumber,
      courierName: order.courierName,
      items: order.items,
      timeline: order.statusHistory.map((h) => ({
        status: h.status,
        time: h.createdAt.toLocaleString("bn-BD"),
        note: h.note,
      })),
    });
  } catch (error) {
    return NextResponse.json({ error: "সার্ভার ত্রুটি" }, { status: 500 });
  }
}
