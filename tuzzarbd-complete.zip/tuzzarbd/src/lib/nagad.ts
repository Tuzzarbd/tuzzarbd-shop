// src/lib/nagad.ts
// Nagad Payment Gateway Integration
// Docs: https://nagad.com.bd/developer

import crypto from "crypto";

const NAGAD_BASE_URL = process.env.NAGAD_BASE_URL || "https://sandbox.mynagad.com:10080/remote-payment-gateway-1.0";
const MERCHANT_ID = process.env.NAGAD_MERCHANT_ID!;
const MERCHANT_PRIVATE_KEY = process.env.NAGAD_MERCHANT_PRIVATE_KEY!;
const NAGAD_PUBLIC_KEY = process.env.NAGAD_PUBLIC_KEY || ""; // Get from Nagad portal
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

// ========================
// RSA ENCRYPT (for Nagad)
// ========================
function encryptWithPublicKey(data: string): string {
  if (!NAGAD_PUBLIC_KEY) return Buffer.from(data).toString("base64");
  const publicKey = `-----BEGIN PUBLIC KEY-----\n${NAGAD_PUBLIC_KEY}\n-----END PUBLIC KEY-----`;
  const encrypted = crypto.publicEncrypt(
    { key: publicKey, padding: crypto.constants.RSA_PKCS1_PADDING },
    Buffer.from(data)
  );
  return encrypted.toString("base64");
}

function signWithPrivateKey(data: string): string {
  if (!MERCHANT_PRIVATE_KEY) return "";
  const privateKey = `-----BEGIN RSA PRIVATE KEY-----\n${MERCHANT_PRIVATE_KEY}\n-----END RSA PRIVATE KEY-----`;
  const sign = crypto.createSign("SHA256withRSA");
  sign.update(data);
  return sign.sign(privateKey, "base64");
}

// ========================
// INITIALIZE PAYMENT
// ========================
export async function initNagadPayment(params: {
  orderId: string;
  amount: number;
  datetime?: string;
}): Promise<{ callBackUrl: string; paymentReferenceId: string }> {
  const datetime = params.datetime || new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
  const sensitiveData = {
    merchantId: MERCHANT_ID,
    datetime,
    orderId: params.orderId,
    challenge: crypto.randomBytes(16).toString("hex"),
  };

  const encryptedSensitiveData = encryptWithPublicKey(JSON.stringify(sensitiveData));
  const signature = signWithPrivateKey(JSON.stringify(sensitiveData));

  const res = await fetch(
    `${NAGAD_BASE_URL}/api/dfs/check-out/initialize/${MERCHANT_ID}/${params.orderId}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "X-KM-Api-Version": "v-0.2.0",
        "X-KM-IP-V4": "127.0.0.1",
        "X-KM-Client-Type": "PC_WEB",
      },
      body: JSON.stringify({
        datetime,
        sensitiveData: encryptedSensitiveData,
        signature,
        merchantCallbackURL: `${SITE_URL}/api/payments/nagad/callback`,
      }),
    }
  );

  if (!res.ok) throw new Error(`Nagad init error: ${res.status}`);
  const data = await res.json();

  if (!data.sensitiveData) throw new Error("Nagad: invalid response");

  // Decrypt response (simplified)
  return {
    callBackUrl: data.callBackUrl,
    paymentReferenceId: data.paymentReferenceId,
  };
}

// ========================
// COMPLETE PAYMENT
// ========================
export async function completeNagadPayment(params: {
  paymentReferenceId: string;
  orderId: string;
  amount: number;
  challenge: string;
}): Promise<{ orderId: string; issuerPaymentRefNo: string; status: string }> {
  const sensitiveData = {
    merchantId: MERCHANT_ID,
    orderId: params.orderId,
    challenge: params.challenge,
    amount: params.amount.toFixed(2),
    currencyCode: "050",
    orderDeliveryAddress: "Dhaka, Bangladesh",
  };

  const encryptedSensitiveData = encryptWithPublicKey(JSON.stringify(sensitiveData));
  const signature = signWithPrivateKey(JSON.stringify(sensitiveData));

  const res = await fetch(
    `${NAGAD_BASE_URL}/api/dfs/check-out/complete/${params.paymentReferenceId}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "X-KM-Api-Version": "v-0.2.0",
      },
      body: JSON.stringify({
        sensitiveData: encryptedSensitiveData,
        signature,
        merchantCallbackURL: `${process.env.NEXT_PUBLIC_SITE_URL}/api/payments/nagad/callback`,
        additionalMerchantInfo: { data: {} },
      }),
    }
  );

  if (!res.ok) throw new Error(`Nagad complete error: ${res.status}`);
  return res.json();
}

// ========================
// VERIFY PAYMENT
// ========================
export async function verifyNagadPayment(paymentRefId: string) {
  const res = await fetch(
    `${NAGAD_BASE_URL}/api/dfs/verify/payment/${paymentRefId}`,
    {
      headers: {
        "X-KM-Api-Version": "v-0.2.0",
        Accept: "application/json",
      },
    }
  );
  return res.json();
}
