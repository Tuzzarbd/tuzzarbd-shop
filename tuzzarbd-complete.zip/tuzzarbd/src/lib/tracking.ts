// src/lib/tracking.ts
// Meta Pixel & Conversion API (CAPI) Integration

declare global {
  interface Window {
    fbq: (...args: unknown[]) => void;
    _fbq: unknown;
  }
}

// ========================
// META PIXEL (Client-Side)
// ========================

export const MetaPixel = {
  pageView: () => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("track", "PageView");
    }
  },

  viewContent: (data: {
    content_ids: string[];
    content_name: string;
    content_type: string;
    value: number;
    currency: string;
  }) => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("track", "ViewContent", data);
    }
  },

  addToCart: (data: {
    content_ids: string[];
    content_name: string;
    value: number;
    currency: string;
    quantity: number;
  }) => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("track", "AddToCart", data);
    }
  },

  initiateCheckout: (data: {
    content_ids: string[];
    num_items: number;
    value: number;
    currency: string;
  }) => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("track", "InitiateCheckout", data);
    }
  },

  purchase: (data: {
    content_ids: string[];
    value: number;
    currency: string;
    num_items: number;
    order_id: string;
  }) => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("track", "Purchase", data);
    }
  },

  addPaymentInfo: () => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("track", "AddPaymentInfo");
    }
  },

  search: (searchString: string) => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("track", "Search", { search_string: searchString });
    }
  },
};

// ========================
// CAPI (Server-Side - Conversion API)
// ========================

interface CAPIEventData {
  event_name: string;
  event_time: number;
  action_source: string;
  user_data: {
    ph?: string[]; // hashed phone
    em?: string[]; // hashed email
    client_ip_address?: string;
    client_user_agent?: string;
    fbc?: string;
    fbp?: string;
  };
  custom_data?: Record<string, unknown>;
  event_id?: string;
}

export async function sendCAPIEvent(data: CAPIEventData): Promise<void> {
  const PIXEL_ID = process.env.META_PIXEL_ID;
  const ACCESS_TOKEN = process.env.META_CAPI_TOKEN;

  if (!PIXEL_ID || !ACCESS_TOKEN) {
    console.log("[CAPI] Skipping - Meta Pixel ID or CAPI token not configured");
    return;
  }

  try {
    const response = await fetch(
      `https://graph.facebook.com/v18.0/${PIXEL_ID}/events?access_token=${ACCESS_TOKEN}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data: [data] }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      console.error("[CAPI] Error:", error);
    }
  } catch (error) {
    console.error("[CAPI] Failed to send event:", error);
  }
}

export async function hashData(data: string): Promise<string> {
  const encoder = new TextEncoder();
  const hashBuffer = await crypto.subtle.digest("SHA-256", encoder.encode(data.toLowerCase().trim()));
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ========================
// GOOGLE ADS (Placeholder)
// ========================

export const GoogleAds = {
  pageView: () => {
    if (typeof window !== "undefined" && (window as unknown as { gtag?: Function }).gtag) {
      (window as unknown as { gtag: Function }).gtag("event", "page_view");
    }
  },

  purchase: (data: { transaction_id: string; value: number; currency: string }) => {
    if (typeof window !== "undefined" && (window as unknown as { gtag?: Function }).gtag) {
      (window as unknown as { gtag: Function }).gtag("event", "purchase", data);
    }
  },
};

// ========================
// WHATSAPP
// ========================

export const WHATSAPP_NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "8801XXXXXXXXX";

export function getWhatsAppLink(message?: string): string {
  const encoded = encodeURIComponent(message || "Hello! I want to order from tuzzarbd.");
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`;
}

export function getProductWhatsAppLink(productName: string, productUrl: string): string {
  const message = `আমি এই পণ্যটি অর্ডার করতে চাই:\n${productName}\n${productUrl}`;
  return getWhatsAppLink(message);
}
