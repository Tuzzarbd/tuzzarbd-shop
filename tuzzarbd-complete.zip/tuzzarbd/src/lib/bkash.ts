// src/lib/bkash.ts
// bKash Tokenized Payment Gateway Integration
// Docs: https://developer.bka.sh/docs

const BKASH_BASE_URL = process.env.BKASH_BASE_URL || "https://tokenized.sandbox.bka.sh/v1.2.0-beta";
const APP_KEY = process.env.BKASH_APP_KEY!;
const APP_SECRET = process.env.BKASH_APP_SECRET!;
const USERNAME = process.env.BKASH_USERNAME!;
const PASSWORD = process.env.BKASH_PASSWORD!;

let cachedToken: { token: string; expiresAt: number } | null = null;

// ========================
// GET TOKEN
// ========================
export async function getBkashToken(): Promise<string> {
  // Use cached token if still valid (token lasts ~3600s)
  if (cachedToken && Date.now() < cachedToken.expiresAt) {
    return cachedToken.token;
  }

  const res = await fetch(`${BKASH_BASE_URL}/tokenized/checkout/token/grant`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      username: USERNAME,
      password: PASSWORD,
    },
    body: JSON.stringify({
      app_key: APP_KEY,
      app_secret: APP_SECRET,
    }),
  });

  if (!res.ok) {
    throw new Error(`bKash token error: ${res.status}`);
  }

  const data = await res.json();
  if (!data.id_token) throw new Error("bKash: id_token not found");

  cachedToken = {
    token: data.id_token,
    expiresAt: Date.now() + 3500 * 1000,
  };

  return cachedToken.token;
}

// ========================
// CREATE PAYMENT
// ========================
export interface BkashCreatePaymentParams {
  amount: number;
  orderId: string;
  intent?: "sale" | "authorization";
}

export interface BkashPaymentResponse {
  paymentID: string;
  bkashURL: string;
  callbackURL: string;
  successCallbackURL: string;
  failureCallbackURL: string;
  cancelledCallbackURL: string;
  amount: string;
  intent: string;
  merchantInvoiceNumber: string;
}

export async function createBkashPayment(params: BkashCreatePaymentParams): Promise<BkashPaymentResponse> {
  const token = await getBkashToken();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

  const res = await fetch(`${BKASH_BASE_URL}/tokenized/checkout/create`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: token,
      "X-APP-Key": APP_KEY,
    },
    body: JSON.stringify({
      mode: "0011",
      payerReference: params.orderId,
      callbackURL: `${siteUrl}/api/payments/bkash/callback`,
      amount: params.amount.toFixed(2),
      currency: "BDT",
      intent: params.intent || "sale",
      merchantInvoiceNumber: params.orderId,
    }),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(`bKash create payment error: ${JSON.stringify(err)}`);
  }

  return res.json();
}

// ========================
// EXECUTE PAYMENT
// ========================
export async function executeBkashPayment(paymentID: string): Promise<{
  trxID: string;
  amount: string;
  merchantInvoiceNumber: string;
  transactionStatus: string;
}> {
  const token = await getBkashToken();

  const res = await fetch(`${BKASH_BASE_URL}/tokenized/checkout/execute`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: token,
      "X-APP-Key": APP_KEY,
    },
    body: JSON.stringify({ paymentID }),
  });

  if (!res.ok) {
    throw new Error(`bKash execute payment error: ${res.status}`);
  }

  return res.json();
}

// ========================
// QUERY PAYMENT
// ========================
export async function queryBkashPayment(paymentID: string) {
  const token = await getBkashToken();

  const res = await fetch(`${BKASH_BASE_URL}/tokenized/checkout/payment/status`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: token,
      "X-APP-Key": APP_KEY,
    },
    body: JSON.stringify({ paymentID }),
  });

  return res.json();
}

// ========================
// REFUND
// ========================
export async function refundBkashPayment(params: {
  paymentID: string;
  trxID: string;
  amount: number;
  reason: string;
}) {
  const token = await getBkashToken();

  const res = await fetch(`${BKASH_BASE_URL}/tokenized/checkout/payment/refund`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: token,
      "X-APP-Key": APP_KEY,
    },
    body: JSON.stringify({
      paymentID: params.paymentID,
      amount: params.amount.toFixed(2),
      trxID: params.trxID,
      sku: "refund",
      reason: params.reason,
    }),
  });

  return res.json();
}
