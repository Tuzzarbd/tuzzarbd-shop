# 🚀 tuzzarbd — Supabase সেটআপ গাইড (বাংলা)

## ধাপ ১: Supabase অ্যাকাউন্ট তৈরি করুন

1. https://supabase.com এ যান
2. **"Start your project"** বাটনে ক্লিক করুন
3. GitHub দিয়ে Sign Up করুন (ফ্রি)

---

## ধাপ ২: নতুন Project তৈরি করুন

1. Dashboard এ **"New Project"** ক্লিক করুন
2. নিম্নলিখিত তথ্য দিন:
   - **Name:** `tuzzarbd`
   - **Database Password:** একটি শক্তিশালী পাসওয়ার্ড দিন (মনে রাখবেন!)
   - **Region:** `Southeast Asia (Singapore)` — বাংলাদেশের জন্য সবচেয়ে কাছে
3. **"Create new project"** ক্লিক করুন
4. ২-৩ মিনিট অপেক্ষা করুন

---

## ধাপ ৩: Database URL সংগ্রহ করুন

Project তৈরি হলে:

1. বাম মেনুতে **Settings** → **Database** যান
2. **"Connection string"** সেকশন থেকে **URI** কপি করুন
   ```
   postgresql://postgres:[YOUR-PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres
   ```
3. `[YOUR-PASSWORD]` এর জায়গায় আপনার পাসওয়ার্ড বসান

---

## ধাপ ৪: API Keys সংগ্রহ করুন

1. **Settings** → **API** যান
2. নিম্নলিখিত কপি করুন:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public** key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role** key → `SUPABASE_SERVICE_KEY` (গোপন রাখুন!)

---

## ধাপ ৫: .env.local ফাইল তৈরি করুন

প্রজেক্টের root ফোল্ডারে `.env.local` ফাইল তৈরি করুন:

```env
# Database
DATABASE_URL="postgresql://postgres:YOUR_PASSWORD@db.YOUR_PROJECT_REF.supabase.co:5432/postgres"

# Supabase
NEXT_PUBLIC_SUPABASE_URL="https://YOUR_PROJECT_REF.supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="your-anon-key-here"
SUPABASE_SERVICE_KEY="your-service-role-key-here"

# Auth
JWT_SECRET="minimum-32-character-random-string-here"

# Admin
ADMIN_EMAIL="admin@tuzzarbd.com"
ADMIN_PASSWORD="আপনার_শক্তিশালী_পাসওয়ার্ড"

# Site
NEXT_PUBLIC_SITE_URL="http://localhost:3000"

# WhatsApp (880 দিয়ে শুরু, 0 ছাড়া)
NEXT_PUBLIC_WHATSAPP_NUMBER="880XXXXXXXXXX"

# bKash
BKASH_APP_KEY="your-bkash-app-key"
BKASH_APP_SECRET="your-bkash-app-secret"
BKASH_USERNAME="your-bkash-username"
BKASH_PASSWORD="your-bkash-password"
BKASH_BASE_URL="https://tokenized.sandbox.bka.sh/v1.2.0-beta"

# Nagad
NAGAD_MERCHANT_ID="your-nagad-merchant-id"
NAGAD_MERCHANT_PRIVATE_KEY="your-nagad-private-key"
NAGAD_BASE_URL="https://sandbox.mynagad.com:10080/remote-payment-gateway-1.0"

# Meta Pixel (পরে যোগ করুন)
NEXT_PUBLIC_META_PIXEL_ID=""
META_CAPI_TOKEN=""
```

---

## ধাপ ৬: Database Schema Push করুন

টার্মিনালে এই কমান্ডগুলো চালান:

```bash
# প্রজেক্ট ফোল্ডারে যান
cd tuzzarbd

# Dependencies install করুন
npm install

# Prisma client generate করুন
npx prisma generate

# Database schema push করুন
npx prisma db push

# (ঐচ্ছিক) Demo data দিয়ে শুরু করুন
npm run db:seed
```

---

## ধাপ ৭: Supabase Storage সেটআপ (ছবি আপলোডের জন্য)

1. Supabase Dashboard → **Storage** যান
2. **"Create a new bucket"** ক্লিক করুন
3. Bucket name: `tuzzarbd-products`
4. **Public bucket** চালু করুন
5. **Create bucket** ক্লিক করুন

---

## ধাপ ৮: প্রজেক্ট চালু করুন

```bash
npm run dev
```

এরপর http://localhost:3000 খুলুন।

**Admin Panel:** http://localhost:3000/admin/login
- Email: admin@tuzzarbd.com  
- Password: আপনার .env এর ADMIN_PASSWORD

---

## ✅ সবকিছু ঠিকঠাক হলে দেখবেন:

- হোমপেজ লোড হচ্ছে
- Admin login কাজ করছে
- Products page দেখা যাচ্ছে

---

## 🆘 সমস্যা হলে:

**Error: DATABASE_URL not found**
→ `.env.local` ফাইল সঠিক জায়গায় আছে কিনা চেক করুন

**Error: relation "products" does not exist**
→ `npx prisma db push` আবার চালান

**Error: Invalid Supabase URL**
→ Supabase URL এর শেষে `/` নেই তো?

---

## 🚀 Production Deploy (Vercel)

```bash
# Vercel CLI install
npm i -g vercel

# Deploy
vercel

# Environment variables Vercel Dashboard থেকে যোগ করুন
# Settings → Environment Variables
```

Vercel এ সব `.env.local` এর variables যোগ করুন।
`NEXT_PUBLIC_SITE_URL` = আপনার Vercel URL দিন।
