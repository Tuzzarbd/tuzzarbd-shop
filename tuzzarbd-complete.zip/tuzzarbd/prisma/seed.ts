// prisma/seed.ts
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  // Admin User
  const adminHash = await bcrypt.hash(process.env.ADMIN_PASSWORD || "admin123", 12);
  const admin = await prisma.user.upsert({
    where: { email: process.env.ADMIN_EMAIL || "admin@tuzzarbd.com" },
    update: {},
    create: {
      name: "Admin",
      email: process.env.ADMIN_EMAIL || "admin@tuzzarbd.com",
      passwordHash: adminHash,
      role: "ADMIN",
      isActive: true,
    },
  });
  console.log("✅ Admin user created:", admin.email);

  // Categories
  const fashionCat = await prisma.category.upsert({
    where: { slug: "fashion" },
    update: {},
    create: {
      name: "ফ্যাশন",
      slug: "fashion",
      type: "FASHION",
      description: "পুরুষ, মহিলা ও শিশুদের পোশাক",
      isActive: true,
      sortOrder: 1,
      metaTitle: "ফ্যাশন পোশাক | tuzzarbd",
    },
  });

  const gadgetsCat = await prisma.category.upsert({
    where: { slug: "gadgets" },
    update: {},
    create: {
      name: "স্মার্ট গ্যাজেট",
      slug: "gadgets",
      type: "GADGETS",
      description: "স্মার্টফোন, ইয়ারফোন, স্মার্টওয়াচ",
      isActive: true,
      sortOrder: 2,
      metaTitle: "স্মার্ট গ্যাজেট | tuzzarbd",
    },
  });

  const beautyCat = await prisma.category.upsert({
    where: { slug: "beauty" },
    update: {},
    create: {
      name: "বিউটি কেয়ার",
      slug: "beauty",
      type: "BEAUTY",
      description: "স্কিনকেয়ার, মেকআপ, হেয়ার কেয়ার",
      isActive: true,
      sortOrder: 3,
      metaTitle: "বিউটি কেয়ার | tuzzarbd",
    },
  });

  console.log("✅ Categories created");

  // Subcategories
  const mensSub = await prisma.subcategory.upsert({
    where: { slug: "mens-clothing" },
    update: {},
    create: { categoryId: fashionCat.id, name: "পুরুষ পোশাক", slug: "mens-clothing", isActive: true, sortOrder: 1 },
  });

  const smartphoneSub = await prisma.subcategory.upsert({
    where: { slug: "smartphones" },
    update: {},
    create: { categoryId: gadgetsCat.id, name: "স্মার্টফোন", slug: "smartphones", isActive: true, sortOrder: 1 },
  });

  const skincareSub = await prisma.subcategory.upsert({
    where: { slug: "skincare" },
    update: {},
    create: { categoryId: beautyCat.id, name: "স্কিনকেয়ার", slug: "skincare", isActive: true, sortOrder: 1 },
  });

  console.log("✅ Subcategories created");

  // Sample Products
  const products = [
    {
      categoryId: fashionCat.id,
      subcategoryId: mensSub.id,
      name: "প্রিমিয়াম কটন শার্ট - Navy Blue",
      slug: "premium-cotton-shirt-navy-blue",
      description: "উচ্চমানের কটন কাপড়ে তৈরি প্রিমিয়াম শার্ট। আরামদায়ক ও টেকসই।",
      shortDesc: "প্রিমিয়াম কটন, আরামদায়ক ফিট",
      price: 850,
      comparePrice: 1200,
      costPrice: 400,
      sku: "SHIRT-NB-001",
      stock: 45,
      isActive: true,
      isFeatured: true,
      attributes: [
        { key: "কাপড়", value: "১০০% কটন", sortOrder: 1 },
        { key: "সাইজ", value: "S, M, L, XL, XXL", sortOrder: 2 },
        { key: "রঙ", value: "Navy Blue", sortOrder: 3 },
        { key: "ধোয়ার নির্দেশনা", value: "মেশিনে ধোয়া যাবে", sortOrder: 4 },
      ],
    },
    {
      categoryId: gadgetsCat.id,
      subcategoryId: smartphoneSub.id,
      name: "Xiaomi Redmi Note 13 Pro",
      slug: "xiaomi-redmi-note-13-pro",
      description: "শক্তিশালী Snapdragon প্রসেসর, ১০৮MP ক্যামেরা, ৫০০০mAh ব্যাটারি।",
      shortDesc: "১০৮MP ক্যামেরা | ৫০০০mAh ব্যাটারি",
      price: 32000,
      comparePrice: 35000,
      costPrice: 28000,
      sku: "PHONE-XRN13P-001",
      stock: 12,
      isActive: true,
      isFeatured: true,
      attributes: [
        { key: "প্রসেসর", value: "Snapdragon 7s Gen 2", sortOrder: 1 },
        { key: "RAM", value: "8GB / 12GB", sortOrder: 2 },
        { key: "স্টোরেজ", value: "256GB", sortOrder: 3 },
        { key: "ক্যামেরা", value: "১০৮MP + ৮MP + ২MP", sortOrder: 4 },
        { key: "ব্যাটারি", value: "৫০০০mAh (67W চার্জিং)", sortOrder: 5 },
        { key: "ডিসপ্লে", value: "6.67\" AMOLED, 120Hz", sortOrder: 6 },
        { key: "ওয়ারেন্টি", value: "১ বছর অফিশিয়াল", sortOrder: 7 },
      ],
    },
    {
      categoryId: beautyCat.id,
      subcategoryId: skincareSub.id,
      name: "ভিটামিন C ব্রাইটেনিং ফেসওয়াশ (100ml)",
      slug: "vitamin-c-brightening-facewash-100ml",
      description: "ভিটামিন C সমৃদ্ধ ফেসওয়াশ যা ত্বক উজ্জ্বল করে, দাগ কমায় ও আর্দ্র রাখে।",
      shortDesc: "উজ্জ্বল ত্বক, দাগ মুক্ত চেহারা",
      price: 350,
      comparePrice: null,
      costPrice: 150,
      sku: "BEAUTY-VCF-001",
      stock: 85,
      isActive: true,
      isFeatured: false,
      isNewArrival: true,
      attributes: [
        { key: "উপাদান", value: "ভিটামিন C, নিয়াসিনামাইড, অ্যালোভেরা", sortOrder: 1 },
        { key: "ত্বকের ধরন", value: "সব ধরনের ত্বক", sortOrder: 2 },
        { key: "হালাল", value: "হ্যাঁ, সার্টিফাইড", sortOrder: 3 },
        { key: "ব্যবহার", value: "সকাল ও রাতে ব্যবহার করুন", sortOrder: 4 },
        { key: "পার্শ্বক্রিয়া", value: "শূন্য (ডার্মাটোলজিস্ট টেস্টেড)", sortOrder: 5 },
        { key: "মেয়াদ", value: "২ বছর", sortOrder: 6 },
      ],
    },
  ];

  for (const productData of products) {
    const { attributes, ...data } = productData;
    const existing = await prisma.product.findUnique({ where: { slug: data.slug } });
    if (!existing) {
      const product = await prisma.product.create({
        data: {
          ...data,
          attributes: { create: attributes },
        },
      });
      console.log("✅ Product created:", product.name);
    }
  }

  // Sample Coupon
  await prisma.coupon.upsert({
    where: { code: "TUZZAR10" },
    update: {},
    create: {
      code: "TUZZAR10",
      description: "১০% ছাড় — প্রথম অর্ডারে",
      discountType: "PERCENTAGE",
      discountValue: 10,
      minOrderAmount: 500,
      maxDiscount: 200,
      usageLimit: 100,
      isActive: true,
    },
  });
  console.log("✅ Coupon TUZZAR10 created");

  // Sample Recent Sales (for popup)
  await prisma.recentSale.createMany({
    data: [
      { name: "রহিম উ.", location: "ঢাকা", product: "কটন শার্ট - Navy Blue", isFake: true },
      { name: "সুমাইয়া খ.", location: "চট্টগ্রাম", product: "ভিটামিন C ফেসওয়াশ", isFake: true },
      { name: "করিম আ.", location: "সিলেট", product: "Redmi Note 13 Pro", isFake: true },
    ],
    skipDuplicates: true,
  });

  // Settings
  const defaultSettings = [
    { key: "site_name", value: "tuzzarbd" },
    { key: "whatsapp_number", value: "880XXXXXXXXXX" },
    { key: "dhaka_shipping", value: "80" },
    { key: "outside_dhaka_shipping", value: "150" },
    { key: "low_stock_threshold", value: "5" },
    { key: "currency", value: "BDT" },
  ];

  for (const setting of defaultSettings) {
    await prisma.setting.upsert({ where: { key: setting.key }, update: {}, create: setting });
  }
  console.log("✅ Default settings created");

  console.log("\n🎉 Database seeding complete!");
  console.log("📧 Admin Email:", process.env.ADMIN_EMAIL || "admin@tuzzarbd.com");
  console.log("🔑 Admin Password:", process.env.ADMIN_PASSWORD || "admin123");
  console.log("🎟️  Test Coupon: TUZZAR10 (10% off)");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
